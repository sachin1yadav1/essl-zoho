#!/usr/bin/env node

require("dotenv").config()
const express = require("express")
const open = require("open")
const ZohoOAuthService = require("../src/services/ZohoOAuthService")
const logger = require("../src/utils/logger")

const app = express()
const oauthService = new ZohoOAuthService()
const PORT = 3000

let server

console.log("=".repeat(60))
console.log("Zoho OAuth Setup")
console.log("=".repeat(60))
console.log()

// OAuth callback route
app.get("/oauth/callback", async (req, res) => {
  const { code, error } = req.query

  if (error) {
    console.error("Authorization failed:", error)
    res.send(`
            <html>
                <body style="font-family: Arial; padding: 50px; text-align: center;">
                    <h1 style="color: red;">Authorization Failed</h1>
                    <p>${error}</p>
                    <p>You can close this window.</p>
                </body>
            </html>
        `)
    setTimeout(() => {
      server.close()
      process.exit(1)
    }, 2000)
    return
  }

  if (!code) {
    res.send(`
            <html>
                <body style="font-family: Arial; padding: 50px; text-align: center;">
                    <h1 style="color: red;">Error</h1>
                    <p>No authorization code received</p>
                    <p>You can close this window.</p>
                </body>
            </html>
        `)
    setTimeout(() => {
      server.close()
      process.exit(1)
    }, 2000)
    return
  }

  try {
    console.log("Exchanging authorization code for tokens...")
    const tokenInfo = await oauthService.exchangeCodeForToken(code)

    console.log("✓ Authorization successful!")
    console.log("✓ Tokens saved to .env file")
    console.log()
    console.log("Token expires at:", tokenInfo.expiresAt)
    console.log()
    console.log("You can now start the sync service with: npm start")

    res.send(`
            <html>
                <body style="font-family: Arial; padding: 50px; text-align: center;">
                    <h1 style="color: green;">✓ Authorization Successful!</h1>
                    <p>Tokens have been saved to your .env file.</p>
                    <p>You can close this window and start the sync service.</p>
                    <hr style="margin: 30px 0;">
                    <p style="font-size: 12px; color: #666;">
                        Token expires at: ${tokenInfo.expiresAt}
                    </p>
                </body>
            </html>
        `)

    setTimeout(() => {
      server.close()
      process.exit(0)
    }, 2000)
  } catch (error) {
    console.error("Failed to exchange authorization code:", error.message)

    res.send(`
            <html>
                <body style="font-family: Arial; padding: 50px; text-align: center;">
                    <h1 style="color: red;">Authorization Failed</h1>
                    <p>${error.message}</p>
                    <p>You can close this window.</p>
                </body>
            </html>
        `)

    setTimeout(() => {
      server.close()
      process.exit(1)
    }, 2000)
  }
})

// Start server
server = app.listen(PORT, async () => {
  console.log(`OAuth callback server started on port ${PORT}`)
  console.log()

  const authUrl = oauthService.getAuthorizationUrl()

  console.log("Opening authorization URL in your browser...")
  console.log()
  console.log("If the browser doesn't open automatically, visit:")
  console.log(authUrl)
  console.log()
  console.log("Waiting for authorization...")
  console.log()

  try {
    await open(authUrl)
  } catch (error) {
    console.log("Could not open browser automatically. Please open the URL manually.")
  }
})

// Handle timeout
setTimeout(
  () => {
    console.log()
    console.log("Authorization timeout. Please try again.")
    server.close()
    process.exit(1)
  },
  5 * 60 * 1000,
) // 5 minutes timeout
