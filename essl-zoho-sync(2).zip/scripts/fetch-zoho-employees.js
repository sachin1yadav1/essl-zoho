#!/usr/bin/env node

require("dotenv").config()
const ZohoService = require("../src/services/ZohoService")
const ZohoOAuthService = require("../src/services/ZohoOAuthService")
const logger = require("../src/utils/logger")
const fs = require("fs")
const path = require("path")

async function fetchZohoEmployees() {
  console.log("=".repeat(70))
  console.log("Fetching All Employees from Zoho People")
  console.log("=".repeat(70))
  console.log()

  const oauthService = new ZohoOAuthService()
  const zohoService = new ZohoService(oauthService)

  try {
    // Check OAuth tokens
    console.log("Checking OAuth authentication...")
    const isValid = await oauthService.ensureValidToken()

    if (!isValid) {
      console.log("✗ OAuth tokens are invalid or expired")
      console.log()
      console.log("Please run: npm run oauth-setup")
      return
    }

    console.log("✓ OAuth authentication valid")
    console.log()

    // Fetch all employees
    console.log("Fetching employees from Zoho People...")
    const employees = await zohoService.getAllEmployees()

    if (!employees || employees.length === 0) {
      console.log("No employees found in Zoho People.")
      console.log()
      console.log("Please check:")
      console.log("  - Employees exist in Zoho People")
      console.log("  - OAuth scope includes ZohoPeople.forms.READ")
      return
    }

    console.log(`✓ Found ${employees.length} employees`)
    console.log()

    // Display employee list
    console.log("Employee List:")
    console.log("-".repeat(70))
    console.log("Zoho ID".padEnd(20) + "Name".padEnd(30) + "Email".padEnd(20))
    console.log("-".repeat(70))

    employees.forEach((emp) => {
      console.log(
        (emp.id || "").padEnd(20) +
          (emp.name || emp.Full_Name || "").padEnd(30) +
          (emp.email || emp.Email || "").padEnd(20),
      )
    })

    console.log("-".repeat(70))
    console.log()

    // Save to file
    const outputFile = path.join(__dirname, "..", "zoho-employees.json")
    fs.writeFileSync(outputFile, JSON.stringify(employees, null, 2))
    console.log(`✓ Employee data saved to: ${outputFile}`)
    console.log()

    console.log("Next Steps:")
    console.log("  1. Compare with essl-employees.json")
    console.log("  2. Match employee codes with Zoho IDs")
    console.log("  3. Update src/config/employee-mapping.js")
    console.log()
  } catch (error) {
    console.error("✗ Failed to fetch employees")
    console.error()
    console.error("Error:", error.message)
    console.error()

    if (error.message.includes("401") || error.message.includes("token")) {
      console.log("Token issue detected. Please run: npm run oauth-setup")
    }
  }
}

fetchZohoEmployees()
