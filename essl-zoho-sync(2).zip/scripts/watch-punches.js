#!/usr/bin/env node

require("dotenv").config()
const ESSLService = require("../src/services/ESSLService")
const employeeMapping = require("../src/config/employee-mapping")
const moment = require("moment")
const fs = require("fs")
const path = require("path")

async function watchPunches() {
  console.log("=".repeat(70))
  console.log("Real-Time Punch Monitor")
  console.log("=".repeat(70))
  console.log()
  console.log("Watching for new punches... (Press Ctrl+C to stop)")
  console.log()

  const esslService = new ESSLService()
  await esslService.initialize()

  let lastLogId = 0
  const logFile = path.join(__dirname, "..", "logs", "punch-monitor.log")

  // Ensure logs directory exists
  const logsDir = path.dirname(logFile)
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true })
  }

  const logToFile = (message) => {
    const timestamp = moment().format("YYYY-MM-DD HH:mm:ss")
    fs.appendFileSync(logFile, `${timestamp} | ${message}\n`)
  }

  console.log(`Log file: ${logFile}`)
  console.log()

  try {
    const today = moment().format("YYYY-MM-DD")
    const todayTransactions = await esslService.getTransactions(today)
    if (todayTransactions.length > 0) {
      // Assuming transactions have a log ID or we use array index
      lastLogId = todayTransactions.length
      console.log(`Starting from log ID: ${lastLogId}`)
    }
  } catch (error) {
    console.log("Starting fresh monitoring...")
  }

  console.log()

  setInterval(async () => {
    try {
      const transactions = await esslService.getTransactionsByLogId(lastLogId, 50)

      if (transactions.length > 0) {
        console.log(`\n[${moment().format("HH:mm:ss")}] Found ${transactions.length} new punch(es)`)
        console.log("-".repeat(70))

        transactions.forEach((t) => {
          const zohoId = employeeMapping[t.EmployeeCode] || "NOT_MAPPED"
          const status = zohoId !== "NOT_MAPPED" ? "✓" : "✗"

          const message = `${status} Code: ${t.EmployeeCode.padEnd(10)} | Time: ${t.DateTime.padEnd(20)} | Direction: ${t.Direction.padEnd(4)} | Device: ${t.DeviceName.padEnd(15)} | Zoho: ${zohoId}`

          console.log(message)
          logToFile(message)
        })

        console.log("-".repeat(70))

        lastLogId += transactions.length
      }
    } catch (error) {
      console.error(`Error: ${error.message}`)
      logToFile(`ERROR: ${error.message}`)
    }
  }, 10000) // Check every 10 seconds
}

watchPunches().catch((error) => {
  console.error("Fatal error:", error.message)
  process.exit(1)
})
