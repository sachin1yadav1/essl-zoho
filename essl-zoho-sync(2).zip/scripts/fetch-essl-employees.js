#!/usr/bin/env node

require("dotenv").config()
const ESSLService = require("../src/services/ESSLService")
const logger = require("../src/utils/logger")
const fs = require("fs")
const path = require("path")

async function fetchESSLEmployees() {
  console.log("=".repeat(70))
  console.log("Fetching All Employees from eSSL")
  console.log("=".repeat(70))
  console.log()

  const esslService = new ESSLService()

  try {
    // Initialize connection
    await esslService.initialize()
    console.log("✓ Connected to eSSL service")
    console.log()

    // Get all employee codes
    console.log("Fetching employee codes...")
    const codes = await esslService.getEmployeeCodes()
    console.log(`✓ Found ${codes.length} employees`)
    console.log()

    if (codes.length === 0) {
      console.log("No employees found in eSSL system.")
      console.log()
      console.log("Please check:")
      console.log("  - Employees are enrolled in eSSL devices")
      console.log("  - ESSL_LOCATION_CODE is correct (or empty for all locations)")
      return
    }

    // Fetch details for each employee
    console.log("Fetching employee details...")
    const employees = []

    for (let i = 0; i < codes.length; i++) {
      const code = codes[i]
      process.stdout.write(`\rProgress: ${i + 1}/${codes.length}`)

      try {
        const employee = await esslService.getEmployee(code)
        if (employee) {
          employees.push(employee)
        }
        // Small delay to avoid overwhelming the API
        await new Promise((resolve) => setTimeout(resolve, 100))
      } catch (error) {
        console.error(`\nError fetching employee ${code}: ${error.message}`)
      }
    }

    console.log("\n")
    console.log(`✓ Successfully fetched ${employees.length} employee details`)
    console.log()

    // Display employee list
    console.log("Employee List:")
    console.log("-".repeat(70))
    console.log("Code".padEnd(15) + "Name".padEnd(30) + "Card Number".padEnd(15) + "Location".padEnd(10))
    console.log("-".repeat(70))

    employees.forEach((emp) => {
      console.log(
        (emp.EmployeeCode || "").padEnd(15) +
          (emp.EmployeeName || "").padEnd(30) +
          (emp.CardNumber || "").padEnd(15) +
          (emp.Location || "").padEnd(10),
      )
    })

    console.log("-".repeat(70))
    console.log()

    // Save to file
    const outputFile = path.join(__dirname, "..", "essl-employees.json")
    fs.writeFileSync(outputFile, JSON.stringify(employees, null, 2))
    console.log(`✓ Employee data saved to: ${outputFile}`)
    console.log()

    // Generate mapping template
    console.log("Generating employee mapping template...")
    const mappingFile = path.join(__dirname, "..", "employee-mapping-template.js")
    let mappingContent = `/**
 * Employee Mapping Template
 * Generated from eSSL on ${new Date().toISOString()}
 * 
 * Instructions:
 * 1. Get Zoho Employee IDs using: npm run fetch-zoho-employees
 * 2. Match eSSL codes with Zoho IDs
 * 3. Copy to src/config/employee-mapping.js
 */

module.exports = {\n`

    employees.forEach((emp) => {
      mappingContent += `  '${emp.EmployeeCode}': 'ZOHO_ID_HERE', // ${emp.EmployeeName}\n`
    })

    mappingContent += `};\n`

    fs.writeFileSync(mappingFile, mappingContent)
    console.log(`✓ Mapping template saved to: ${mappingFile}`)
    console.log()

    console.log("Next Steps:")
    console.log("  1. Run: npm run fetch-zoho-employees")
    console.log("  2. Match eSSL codes with Zoho IDs")
    console.log("  3. Update src/config/employee-mapping.js")
    console.log()
  } catch (error) {
    console.error("✗ Failed to fetch employees")
    console.error()
    console.error("Error:", error.message)
    console.error()
  }
}

fetchESSLEmployees()
