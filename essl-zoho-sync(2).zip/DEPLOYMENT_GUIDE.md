# Complete Deployment Guide - eSSL to Zoho People Sync

## Table of Contents
1. [System Overview](#system-overview)
2. [Prerequisites](#prerequisites)
3. [Installation Steps](#installation-steps)
4. [Configuration](#configuration)
5. [Employee Mapping](#employee-mapping)
6. [Testing](#testing)
7. [Production Deployment](#production-deployment)
8. [Monitoring & Maintenance](#monitoring--maintenance)
9. [Troubleshooting](#troubleshooting)

---

## System Overview

### What This System Does

This application automatically syncs biometric punch data from eSSL devices to Zoho People attendance system.

**Key Features:**
- Real-time sync of employee punch data (check-in/check-out)
- Time-based intelligent polling (more frequent during peak hours)
- Automatic retry and error handling
- Detailed logging with employee names and punch times
- Health monitoring dashboard
- Production-ready with PM2 process management

**How It Works:**
1. System connects to eSSL biometric devices via SOAP API
2. Fetches punch transactions every 15-30 seconds (based on time of day)
3. Maps eSSL employee codes to Zoho employee IDs
4. Sends attendance data to Zoho People API
5. Logs all activities with detailed information

**Time-Based Sync Intervals:**
- **8am-11am**: Every 15 seconds (catches late arrivals after 10am)
- **11am-2pm**: Every 30 seconds (lunch time punches)
- **2pm-6pm**: Every 15 seconds (afternoon activity)
- **After 6pm**: Every 30 seconds (evening departures)
- **Before 8am**: Every 5 minutes (minimal activity)

---

## Prerequisites

### Required Software
- **Node.js**: Version 16.0.0 or higher
- **npm**: Version 7.0.0 or higher
- **PM2**: For production deployment (optional but recommended)

### Required Access
1. **eSSL System:**
   - eSSL eBioServerNew web service URL
   - Admin username and password
   - Network access to eSSL server

2. **Zoho People:**
   - Zoho People account (India DC)
   - API access enabled
   - OAuth client credentials (Client ID & Secret)

### System Requirements
- **OS**: Linux, Windows, or macOS
- **RAM**: Minimum 512MB
- **Disk**: 1GB free space for logs
- **Network**: Stable internet connection

---

## Installation Steps

### Step 1: Download and Extract

\`\`\`bash
# Download the project
git clone <repository-url>
cd essl-zoho-sync

# Or if you have a ZIP file
unzip essl-zoho-sync.zip
cd essl-zoho-sync
\`\`\`

### Step 2: Install Dependencies

\`\`\`bash
npm install
\`\`\`

This will install all required packages:
- axios (HTTP client)
- express (Web server)
- winston (Logging)
- moment (Date handling)
- xml2js (XML parsing)
- dotenv (Environment variables)

### Step 3: Create Environment File

\`\`\`bash
# Copy the example environment file
cp .env.example .env
\`\`\`

---

## Configuration

### Step 1: Configure eSSL Connection

Edit `.env` file and add your eSSL details:

\`\`\`env
# eSSL Configuration
ESSL_WEBSERVICE_URL=http://192.168.1.100/webservice.asmx
ESSL_USERNAME=admin
ESSL_PASSWORD=your_password
ESSL_LOCATION_CODE=
\`\`\`

**How to find these values:**

1. **ESSL_WEBSERVICE_URL**: 
   - This is your eSSL eBioServerNew web service URL
   - Format: `http://<server-ip>/webservice.asmx`
   - Example: `http://192.168.1.100/webservice.asmx`

2. **ESSL_USERNAME & ESSL_PASSWORD**:
   - These are your eBioServerNew admin credentials
   - Same credentials you use to login to eBioServerNew application

3. **ESSL_LOCATION_CODE**:
   - Leave empty if you have only one location
   - Run `npm run list-locations` to see available locations
   - Only needed if you have multiple locations

### Step 2: Configure Zoho OAuth

\`\`\`env
# Zoho OAuth Configuration
ZOHO_CLIENT_ID=your_client_id
ZOHO_CLIENT_SECRET=your_client_secret
ZOHO_REDIRECT_URI=http://localhost:3000/oauth/callback
ZOHO_SCOPE=ZohoPeople.attendance.CREATE,ZohoPeople.forms.READ
ZOHO_ACCOUNTS_URL=https://accounts.zoho.in
\`\`\`

**How to get Zoho OAuth credentials:**

1. Go to [Zoho API Console](https://api-console.zoho.in/)
2. Click "Add Client"
3. Choose "Server-based Applications"
4. Fill in details:
   - Client Name: `eSSL Sync`
   - Homepage URL: `http://localhost:3000`
   - Authorized Redirect URI: `http://localhost:3000/oauth/callback`
5. Click "Create"
6. Copy the Client ID and Client Secret to your `.env` file

### Step 3: Test Connections

\`\`\`bash
# Test eSSL connection
npm run test-essl

# Test Zoho connection (after OAuth setup)
npm run test-zoho
\`\`\`

### Step 4: Setup Zoho OAuth Authorization

\`\`\`bash
npm run oauth-setup
\`\`\`

This will:
1. Open a browser window for Zoho authorization
2. Ask you to login to Zoho and grant permissions
3. Automatically save the access token to `.env` file

---

## Employee Mapping

### Understanding Employee Mapping

The system needs to know which eSSL employee code corresponds to which Zoho employee ID.

**Example:**
- eSSL Employee Code: `EMP001`
- Zoho Employee ID: `123456789`

### Step 1: Get eSSL Employee Codes

\`\`\`bash
npm run fetch-essl-employees
\`\`\`

This will:
- Fetch all employees from eSSL system
- Display a table with employee codes and names
- Save data to `essl-employees.json`

**Output example:**
\`\`\`
┌─────────┬──────────────┬─────────────────┬──────────┐
│ (index) │ EmployeeCode │  EmployeeName   │ Location │
├─────────┼──────────────┼─────────────────┼──────────┤
│    0    │   'EMP001'   │  'John Doe'     │ 'Office' │
│    1    │   'EMP002'   │  'Jane Smith'   │ 'Office' │
└─────────┴──────────────┴─────────────────┴──────────┘
\`\`\`

### Step 2: Get Zoho Employee IDs

\`\`\`bash
npm run fetch-zoho-employees
\`\`\`

This will:
- Fetch all employees from Zoho People
- Display a table with employee IDs and names
- Save data to `zoho-employees.json`

**Output example:**
\`\`\`
┌─────────┬──────────────┬─────────────────┬────────────────────┐
│ (index) │      id      │      name       │       email        │
├─────────┼──────────────┼─────────────────┼────────────────────┤
│    0    │ '123456789'  │  'John Doe'     │ 'john@company.com' │
│    1    │ '987654321'  │  'Jane Smith'   │ 'jane@company.com' │
└─────────┴──────────────┴─────────────────┴────────────────────┘
\`\`\`

### Step 3: Create Employee Mapping

Edit `src/config/employee-mapping.js`:

\`\`\`javascript
module.exports = {
  // eSSL Code: Zoho Employee ID
  'EMP001': '123456789',
  'EMP002': '987654321',
  'EMP003': '456789123',
  // Add all your employees here
}
\`\`\`

**Important Notes:**
- eSSL codes are on the left (in quotes)
- Zoho IDs are on the right (in quotes)
- Match employees by name to ensure correct mapping
- Unmapped employees will be skipped with a warning in logs

---

## Testing

### Test Individual Components

\`\`\`bash
# Test eSSL connection and fetch today's punches
npm run test-essl

# Test Zoho connection and API access
npm run test-zoho

# List all locations in eSSL
npm run list-locations

# Fetch all employees from eSSL
npm run fetch-essl-employees

# Fetch all employees from Zoho
npm run fetch-zoho-employees
\`\`\`

### Watch Live Punches

\`\`\`bash
npm run watch-punches
\`\`\`

This will:
- Display real-time punch data as employees punch in/out
- Show employee codes, names, and punch times
- Help you verify the system is working correctly

**Output example:**
\`\`\`
=== Live Punch Monitor ===
Press Ctrl+C to stop

[2025-01-10 09:15:30] ✓ SUCCESS
  eSSL Code: EMP001
  Name: John Doe
  Zoho ID: 123456789
  Punch Time: 2025-01-10 09:15:30
  Device: Main Gate

[2025-01-10 09:16:45] ✓ SUCCESS
  eSSL Code: EMP002
  Name: Jane Smith
  Zoho ID: 987654321
  Punch Time: 2025-01-10 09:16:45
  Device: Main Gate
\`\`\`

### Test in Development Mode

\`\`\`bash
npm run dev
\`\`\`

This runs the application with auto-restart on file changes (using nodemon).

---

## Production Deployment

### Option 1: Using PM2 (Recommended)

PM2 is a production process manager that keeps your application running 24/7.

#### Install PM2

\`\`\`bash
npm install -g pm2
\`\`\`

#### Start Application

\`\`\`bash
npm run pm2:start
\`\`\`

This will:
- Start the application in background
- Auto-restart on crashes
- Enable log rotation
- Monitor CPU and memory usage

#### PM2 Commands

\`\`\`bash
# View application status
pm2 status

# View logs
npm run pm2:logs

# Monitor in real-time
npm run pm2:monit

# Restart application
npm run pm2:restart

# Stop application
npm run pm2:stop

# View detailed info
pm2 show essl-zoho-sync
\`\`\`

#### Auto-Start on System Boot

\`\`\`bash
# Generate startup script
pm2 startup

# Save current process list
pm2 save
\`\`\`

### Option 2: Using Docker

#### Build Docker Image

\`\`\`bash
docker build -t essl-zoho-sync .
\`\`\`

#### Run with Docker Compose

\`\`\`bash
docker-compose up -d
\`\`\`

#### Docker Commands

\`\`\`bash
# View logs
docker-compose logs -f

# Stop application
docker-compose down

# Restart application
docker-compose restart
\`\`\`

### Option 3: Using systemd (Linux)

Create `/etc/systemd/system/essl-sync.service`:

\`\`\`ini
[Unit]
Description=eSSL to Zoho People Sync Service
After=network.target

[Service]
Type=simple
User=your-user
WorkingDirectory=/path/to/essl-zoho-sync
ExecStart=/usr/bin/node src/index.js
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=essl-sync

[Install]
WantedBy=multi-user.target
\`\`\`

Enable and start:

\`\`\`bash
sudo systemctl enable essl-sync
sudo systemctl start essl-sync
sudo systemctl status essl-sync
\`\`\`

---

## Monitoring & Maintenance

### Health Check Dashboard

Access the health dashboard at: `http://localhost:3000/health`

**Available Endpoints:**

\`\`\`bash
# Health status
curl http://localhost:3000/health

# Sync service status
curl http://localhost:3000/status

# Service statistics
curl http://localhost:3000/stats
\`\`\`

### Log Files

Logs are stored in the `logs/` directory:

- `app.log` - All application logs
- `error.log` - Error logs only
- `punch.log` - Detailed punch sync logs

**View logs:**

\`\`\`bash
# View all logs
tail -f logs/app.log

# View punch logs only
tail -f logs/punch.log

# View errors only
tail -f logs/error.log

# Search for specific employee
grep "EMP001" logs/punch.log
\`\`\`

### Log Format

**Punch log format:**
\`\`\`
2025-01-10 09:15:30 [info]: ✓ SUCCESS | eSSL: EMP001 | Name: John Doe | Zoho: 123456789 | Time: 2025-01-10 09:15:30
\`\`\`

This makes it easy to:
- See which employee punched
- Verify the punch time
- Check if sync was successful
- Debug any issues

### Performance Monitoring

\`\`\`bash
# Using PM2
pm2 monit

# View memory usage
pm2 show essl-zoho-sync
\`\`\`

### Database Backup (Optional)

If you're storing sync history, backup regularly:

\`\`\`bash
# Backup logs
tar -czf logs-backup-$(date +%Y%m%d).tar.gz logs/

# Backup configuration
cp .env .env.backup
\`\`\`

---

## Troubleshooting

### Common Issues

#### 1. eSSL Connection Failed

**Error:** `Failed to connect to eSSL service`

**Solutions:**
- Check if eSSL server is running
- Verify ESSL_WEBSERVICE_URL is correct
- Test network connectivity: `ping <essl-server-ip>`
- Check firewall settings
- Verify username and password

**Test:**
\`\`\`bash
npm run test-essl
\`\`\`

#### 2. Zoho Authentication Failed

**Error:** `No access token available` or `Token expired`

**Solutions:**
- Run OAuth setup again: `npm run oauth-setup`
- Check if Client ID and Secret are correct
- Verify redirect URI matches exactly
- Ensure you're using India DC (accounts.zoho.in)

**Test:**
\`\`\`bash
npm run test-zoho
\`\`\`

#### 3. Employee Not Syncing

**Error:** `No Zoho mapping found for eSSL employee: EMP001`

**Solutions:**
- Check if employee is in `employee-mapping.js`
- Verify eSSL code matches exactly (case-sensitive)
- Verify Zoho ID is correct
- Run fetch scripts to get latest employee lists

**Test:**
\`\`\`bash
npm run fetch-essl-employees
npm run fetch-zoho-employees
\`\`\`

#### 4. Punch Not Appearing in Zoho

**Possible causes:**
- Employee mapping is incorrect
- Zoho API permissions missing
- Date/time format mismatch
- Network issues

**Debug steps:**
1. Check punch logs: `tail -f logs/punch.log`
2. Look for SUCCESS or FAILED status
3. Check error message if failed
4. Verify employee mapping
5. Test Zoho connection

#### 5. High Memory Usage

**Solutions:**
- Reduce batch size in `.env`: `SYNC_BATCH_SIZE=5`
- Increase sync interval: `ESSL_BASE_INTERVAL=60000`
- Enable log rotation
- Restart application: `pm2 restart essl-zoho-sync`

#### 6. Application Crashes

**Check logs:**
\`\`\`bash
# PM2 logs
pm2 logs essl-zoho-sync --lines 100

# Application logs
tail -100 logs/error.log
\`\`\`

**Common causes:**
- Out of memory
- Network timeout
- Invalid configuration
- Database connection lost

**Solutions:**
- Check error logs for specific error
- Verify all configuration values
- Ensure network is stable
- Restart application

### Debug Mode

Enable debug logging in `.env`:

\`\`\`env
LOG_LEVEL=debug
\`\`\`

This will show detailed information about:
- SOAP requests and responses
- API calls
- Data transformations
- Sync cycles

### Getting Help

If you're still having issues:

1. Check logs: `logs/error.log`
2. Enable debug mode
3. Test individual components
4. Verify configuration
5. Check network connectivity

---

## Best Practices

### Security

1. **Protect credentials:**
   - Never commit `.env` file to git
   - Use environment variables in production
   - Rotate passwords regularly

2. **Network security:**
   - Use HTTPS for eSSL if available
   - Restrict access to health endpoints
   - Use firewall rules

### Performance

1. **Optimize sync intervals:**
   - Adjust based on your needs
   - Use longer intervals during off-hours
   - Monitor system resources

2. **Log management:**
   - Enable log rotation
   - Archive old logs
   - Monitor disk space

### Reliability

1. **Use PM2 or systemd:**
   - Auto-restart on crashes
   - Start on system boot
   - Monitor process health

2. **Monitor regularly:**
   - Check health dashboard daily
   - Review error logs
   - Verify sync statistics

3. **Backup configuration:**
   - Backup `.env` file
   - Backup employee mapping
   - Document any customizations

---

## Quick Reference

### Essential Commands

\`\`\`bash
# Installation
npm install

# Configuration
npm run setup
npm run oauth-setup

# Testing
npm run test-essl
npm run test-zoho
npm run watch-punches

# Employee Mapping
npm run fetch-essl-employees
npm run fetch-zoho-employees

# Production
npm run pm2:start
npm run pm2:logs
npm run pm2:restart
npm run pm2:stop

# Monitoring
curl http://localhost:3000/health
tail -f logs/punch.log
pm2 monit
\`\`\`

### Important Files

- `.env` - Configuration
- `src/config/employee-mapping.js` - Employee mapping
- `logs/punch.log` - Punch sync logs
- `logs/error.log` - Error logs
- `ecosystem.config.js` - PM2 configuration

### Support

For issues or questions:
1. Check this guide
2. Review logs
3. Test individual components
4. Enable debug mode

---

## Appendix

### Environment Variables Reference

\`\`\`env
# eSSL Configuration
ESSL_WEBSERVICE_URL=http://192.168.1.100/webservice.asmx
ESSL_USERNAME=admin
ESSL_PASSWORD=password
ESSL_LOCATION_CODE=
ESSL_BASE_INTERVAL=30000
ESSL_MIN_INTERVAL=15000
ESSL_MAX_INTERVAL=300000
ESSL_TIMEOUT=30000

# Zoho OAuth
ZOHO_CLIENT_ID=your_client_id
ZOHO_CLIENT_SECRET=your_client_secret
ZOHO_REDIRECT_URI=http://localhost:3000/oauth/callback
ZOHO_SCOPE=ZohoPeople.attendance.CREATE,ZohoPeople.forms.READ
ZOHO_ACCOUNTS_URL=https://accounts.zoho.in

# Zoho API
ZOHO_API_URL=https://people.zoho.in/people/api
ZOHO_ATTENDANCE_API_URL=https://people.zoho.in/people/api/attendance
ZOHO_EMPLOYEE_API_URL=https://people.zoho.in/api/forms/P_EmployeeView/records
ZOHO_TIMEOUT=15000
ZOHO_MAX_RETRIES=3
ZOHO_RATE_LIMIT_DELAY=1000

# Sync Configuration
SYNC_BATCH_SIZE=10
SYNC_EMPTY_POLLS_TO_BACKOFF=5
SYNC_BACKOFF_FACTOR=1.5

# Health Check
HEALTH_CHECK_PORT=3000
HEALTH_CHECK_ENABLED=true

# Logging
LOG_LEVEL=info
LOG_FILE=logs/app.log
LOG_MAX_SIZE=10m
LOG_MAX_FILES=7

# Environment
NODE_ENV=production
\`\`\`

### API Endpoints

\`\`\`
GET  /health          - Health check
GET  /status          - Sync service status
GET  /stats           - Service statistics
POST /sync/start      - Start sync service
POST /sync/stop       - Stop sync service
GET  /oauth/callback  - OAuth callback (auto-handled)
\`\`\`

---

**End of Deployment Guide**

For the latest updates and documentation, visit the project repository.
