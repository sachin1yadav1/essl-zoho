/**
 * Employee Mapping Configuration
 *
 * Maps eSSL employee codes to Zoho People employee IDs
 *
 * Format:
 * 'ESSL_EMPLOYEE_CODE': 'ZOHO_EMPLOYEE_ID'
 *
 * Example:
 * 'E001': '1234567890',
 * 'E002': '1234567891',
 *
 * To auto-generate this mapping from Zoho:
 * Run: npm run setup
 */

module.exports = {
  // Add your employee mappings here
  // 'ESSL_CODE': 'ZOHO_ID',
}
