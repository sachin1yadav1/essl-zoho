require("dotenv").config()

module.exports = {
  // eSSL Configuration
  essl: {
    webserviceUrl: process.env.ESSL_WEBSERVICE_URL || "http://localhost/webservice.asmx",
    username: process.env.ESSL_USERNAME || "admin",
    password: process.env.ESSL_PASSWORD || "",
    locationCode: process.env.ESSL_LOCATION_CODE || "", // Leave empty for all locations (single location setup)
    baseInterval: Number.parseInt(process.env.ESSL_BASE_INTERVAL) || 30000,
    minInterval: Number.parseInt(process.env.ESSL_MIN_INTERVAL) || 15000,
    maxInterval: Number.parseInt(process.env.ESSL_MAX_INTERVAL) || 300000,
    dateFormat: process.env.ESSL_DATE_FORMAT || "YYYY-MM-DD HH:mm:ss",
    initialSyncWindowMinutes: Number.parseInt(process.env.ESSL_INITIAL_SYNC_WINDOW_MINUTES) || 120,
    timeout: Number.parseInt(process.env.ESSL_TIMEOUT) || 30000,
  },

  // Zoho Configuration
  zoho: {
    oauth: {
      clientId: process.env.ZOHO_CLIENT_ID || "",
      clientSecret: process.env.ZOHO_CLIENT_SECRET || "",
      redirectUri: process.env.ZOHO_REDIRECT_URI || "http://localhost:3000/oauth/callback",
      scope: process.env.ZOHO_SCOPE || "ZohoPeople.attendance.CREATE,ZohoPeople.forms.READ",
      accountsUrl: process.env.ZOHO_ACCOUNTS_URL || "https://accounts.zoho.in",
      accessToken: process.env.ZOHO_ACCESS_TOKEN || "",
      refreshToken: process.env.ZOHO_REFRESH_TOKEN || "",
      tokenExpiresAt: process.env.ZOHO_TOKEN_EXPIRES_AT || "",
    },
    apiUrl: process.env.ZOHO_API_URL || "https://people.zoho.in/people/api",
    attendanceApiUrl: process.env.ZOHO_ATTENDANCE_API_URL || "https://people.zoho.in/people/api/attendance",
    employeeApiUrl: process.env.ZOHO_EMPLOYEE_API_URL || "https://people.zoho.in/api/forms/P_EmployeeView/records",
    timeout: Number.parseInt(process.env.ZOHO_TIMEOUT) || 15000,
    maxRetries: Number.parseInt(process.env.ZOHO_MAX_RETRIES) || 3,
    rateLimitDelay: Number.parseInt(process.env.ZOHO_RATE_LIMIT_DELAY) || 1000,
  },

  // Sync Configuration
  sync: {
    batchSize: Number.parseInt(process.env.SYNC_BATCH_SIZE) || 10,
    emptyPollsToBackoff: Number.parseInt(process.env.SYNC_EMPTY_POLLS_TO_BACKOFF) || 5,
    backoffFactor: Number.parseFloat(process.env.SYNC_BACKOFF_FACTOR) || 1.5,
    lastSyncTime: process.env.LAST_SYNC_TIME || "",
  },

  // Health Monitor Configuration
  health: {
    port: Number.parseInt(process.env.HEALTH_CHECK_PORT) || 3000,
    enabled: process.env.HEALTH_CHECK_ENABLED === "true",
  },

  // Logging Configuration
  logging: {
    level: process.env.LOG_LEVEL || "info",
    file: process.env.LOG_FILE || "logs/app.log",
    maxSize: process.env.LOG_MAX_SIZE || "10m",
    maxFiles: Number.parseInt(process.env.LOG_MAX_FILES) || 7,
  },

  // Environment
  env: process.env.NODE_ENV || "development",
  isProduction: process.env.NODE_ENV === "production",
}
