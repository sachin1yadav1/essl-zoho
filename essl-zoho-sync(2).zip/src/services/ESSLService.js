const axios = require("axios")
const xml2js = require("xml2js")
const config = require("../config/config")
const logger = require("../utils/logger")
const moment = require("moment") // Added for date formatting

class ESSLService {
  constructor() {
    this.url = config.essl.webserviceUrl
    this.username = config.essl.username
    this.password = config.essl.password
    this.locationCode = config.essl.locationCode
    this.timeout = config.essl.timeout
    this.requestCount = 0
    this.failedRequests = 0
    this.parser = new xml2js.Parser({ explicitArray: false })
  }

  /**
   * Create SOAP envelope for eSSL web service
   */
  createSoapEnvelope(methodName, parameters) {
    let paramsXml = ""
    for (const [key, value] of Object.entries(parameters)) {
      paramsXml += `      <${key}>${this.escapeXml(value)}</${key}>\n`
    }

    return `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
               xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
               xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <${methodName} xmlns="http://tempuri.org/">
${paramsXml}    </${methodName}>
  </soap:Body>
</soap:Envelope>`
  }

  escapeXml(unsafe) {
    if (unsafe === null || unsafe === undefined) return ""
    return String(unsafe)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;")
  }

  /**
   * Make SOAP request to eSSL service
   */
  async makeSoapRequest(methodName, parameters) {
    this.requestCount++

    try {
      const soapEnvelope = this.createSoapEnvelope(methodName, parameters)

      logger.debug(`Making SOAP request: ${methodName}`)

      const response = await axios.post(this.url, soapEnvelope, {
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
          SOAPAction: `http://tempuri.org/${methodName}`,
        },
        timeout: this.timeout,
      })

      // Parse SOAP response
      const result = await this.parser.parseStringPromise(response.data)

      // Extract result from SOAP envelope
      const body = result["soap:Envelope"]["soap:Body"]
      const responseKey = `${methodName}Response`
      const resultKey = `${methodName}Result`

      if (body && body[responseKey] && body[responseKey][resultKey]) {
        return body[responseKey][resultKey]
      }

      logger.warn(`No result found in SOAP response for ${methodName}`)
      return null
    } catch (error) {
      this.failedRequests++

      if (error.response) {
        // SOAP fault or HTTP error
        logger.error(`SOAP request failed: ${error.response.status} - ${error.response.statusText}`)
        if (error.response.data) {
          logger.debug(`Response data: ${error.response.data}`)
        }
      } else if (error.request) {
        // Network error
        logger.error(`Network error: ${error.message}`)
      } else {
        logger.error(`Request error: ${error.message}`)
      }

      throw error
    }
  }

  /**
   * Initialize and test connection to eSSL service
   */
  async initialize() {
    try {
      logger.info(`Connecting to eSSL SOAP service: ${this.url}`)

      // Test connection by getting device list
      await this.makeSoapRequest("GetDeviceList", {
        UserName: this.username,
        Password: this.password,
        Location: this.locationCode,
      })

      logger.success("eSSL SOAP service connected successfully")
      return true
    } catch (error) {
      logger.error(`Failed to connect to eSSL service: ${error.message}`)
      throw error
    }
  }

  /**
   * Get device logs (punch transactions) for a specific date
   */
  async getTransactions(logDate) {
    try {
      const formattedDate = this.formatDateForESSL(logDate)

      const result = await this.makeSoapRequest("GetDeviceLogs", {
        UserName: this.username,
        Password: this.password,
        Location: this.locationCode,
        LogDate: formattedDate,
      })

      if (!result || result.trim() === "") {
        logger.debug(`No transactions found for date: ${logDate}`)
        return []
      }

      const transactions = this.parseTransactionResult(result)
      logger.debug(`Retrieved ${transactions.length} transactions for ${logDate}`)

      return transactions
    } catch (error) {
      logger.error(`Failed to get transactions for ${logDate}: ${error.message}`)
      throw error
    }
  }

  /**
   * Get device logs by log ID (for incremental sync)
   */
  async getTransactionsByLogId(lastLogId, logCount = 100) {
    try {
      const result = await this.makeSoapRequest("GetDeviceLogsByLogId", {
        UserName: this.username,
        Password: this.password,
        Location: this.locationCode,
        LogId: String(lastLogId),
        LogCount: String(logCount),
      })

      if (!result || result.trim() === "") {
        return []
      }

      const transactions = this.parseTransactionResult(result)
      logger.debug(`Retrieved ${transactions.length} transactions from log ID ${lastLogId}`)

      return transactions
    } catch (error) {
      logger.error(`Failed to get transactions by log ID: ${error.message}`)
      throw error
    }
  }

  /**
   * Get list of all devices
   */
  async getDevices() {
    try {
      const result = await this.makeSoapRequest("GetDeviceList", {
        UserName: this.username,
        Password: this.password,
        Location: this.locationCode,
      })

      if (!result || result.trim() === "") {
        return []
      }

      const devices = this.parseDeviceResult(result)
      logger.info(`Retrieved ${devices.length} devices from eSSL`)

      return devices
    } catch (error) {
      logger.error(`Failed to get devices: ${error.message}`)
      throw error
    }
  }

  /**
   * Get employee details by employee code
   */
  async getEmployee(employeeCode) {
    try {
      const result = await this.makeSoapRequest("GetEmployeeDetails", {
        UserName: this.username,
        Password: this.password,
        EmployeeCode: employeeCode,
      })

      if (!result || result.trim() === "") {
        return null
      }

      return this.parseEmployeeResult(result)
    } catch (error) {
      logger.error(`Failed to get employee ${employeeCode}: ${error.message}`)
      return null
    }
  }

  /**
   * Get all employee codes
   */
  async getEmployeeCodes() {
    try {
      const result = await this.makeSoapRequest("GetEmployeeCodes", {
        UserName: this.username,
        Password: this.password,
        EmployeeCode: "", // Empty to get all
      })

      if (!result || result.trim() === "") {
        return []
      }

      const codes = this.parseEmployeeCodesResult(result)
      logger.info(`Retrieved ${codes.length} employee codes from eSSL`)

      return codes
    } catch (error) {
      logger.error(`Failed to get employee codes: ${error.message}`)
      throw error
    }
  }

  /**
   * Parse transaction result string
   * Format: "DateTime,EmployeeCode,DeviceName,Location,Direction;..."
   * Example: "27-Mar-2025 09:15:30,EMP001,Main Gate,Office,IN;27-Mar-2025 18:30:45,EMP001,Main Gate,Office,OUT;"
   */
  parseTransactionResult(resultString) {
    if (!resultString || resultString.trim() === "") {
      return []
    }

    try {
      const transactions = []
      const records = resultString.split(";").filter((r) => r.trim())

      for (const record of records) {
        const fields = record.split(",").map((f) => f.trim())

        if (fields.length >= 5) {
          const dateTime = fields[0]
          const [datePart, timePart] = dateTime.includes(" ") ? dateTime.split(" ") : [dateTime, "00:00:00"]

          transactions.push({
            DateTime: dateTime,
            PunchDate: datePart,
            PunchTime: timePart,
            EmployeeCode: fields[1],
            DeviceName: fields[2],
            Location: fields[3],
            Direction: fields[4].toUpperCase(), // IN or OUT
            RawData: record,
          })
        }
      }

      return transactions
    } catch (error) {
      logger.error(`Failed to parse transaction result: ${error.message}`)
      logger.debug(`Raw result: ${resultString}`)
      return []
    }
  }

  /**
   * Parse device result string
   * Format: "SerialNumber,DeviceName,Location,Status;..."
   */
  parseDeviceResult(resultString) {
    if (!resultString || resultString.trim() === "") {
      return []
    }

    try {
      const devices = []
      const records = resultString.split(";").filter((r) => r.trim())

      for (const record of records) {
        const fields = record.split(",").map((f) => f.trim())

        if (fields.length >= 3) {
          devices.push({
            SerialNumber: fields[0],
            DeviceName: fields[1],
            Location: fields[2],
            Status: fields[3] || "Unknown",
          })
        }
      }

      return devices
    } catch (error) {
      logger.error(`Failed to parse device result: ${error.message}`)
      return []
    }
  }

  /**
   * Parse employee result string
   * Format: "EmployeeCode,EmployeeName,CardNumber,Location,Role"
   */
  parseEmployeeResult(resultString) {
    if (!resultString || resultString.trim() === "") {
      return null
    }

    try {
      const fields = resultString.split(",").map((f) => f.trim())

      if (fields.length >= 2) {
        return {
          EmployeeCode: fields[0],
          EmployeeName: fields[1],
          CardNumber: fields[2] || "",
          Location: fields[3] || "",
          Role: fields[4] || "",
        }
      }

      return null
    } catch (error) {
      logger.error(`Failed to parse employee result: ${error.message}`)
      return null
    }
  }

  /**
   * Parse employee codes result
   * Format: "CODE1;CODE2;CODE3;..."
   */
  parseEmployeeCodesResult(resultString) {
    if (!resultString || resultString.trim() === "") {
      return []
    }

    try {
      return resultString
        .split(";")
        .map((code) => code.trim())
        .filter((code) => code.length > 0)
    } catch (error) {
      logger.error(`Failed to parse employee codes: ${error.message}`)
      return []
    }
  }

  /**
   * Test connection to eSSL service
   */
  async testConnection() {
    try {
      logger.info("Testing eSSL connection...")

      await this.initialize()

      // Try to get device list as a connection test
      const devices = await this.getDevices()

      logger.success(`eSSL connection successful. Found ${devices.length} devices.`)

      return {
        success: true,
        message: "Connected to eSSL service",
        deviceCount: devices.length,
        devices: devices,
      }
    } catch (error) {
      logger.error(`eSSL connection test failed: ${error.message}`)
      return {
        success: false,
        error: error.message,
      }
    }
  }

  /**
   * Get service statistics
   */
  getStats() {
    return {
      requestCount: this.requestCount,
      failedRequests: this.failedRequests,
      successRate:
        this.requestCount > 0
          ? (((this.requestCount - this.failedRequests) / this.requestCount) * 100).toFixed(2) + "%"
          : "0%",
    }
  }

  /**
   * Format date for eSSL API (DD-MMM-YYYY format)
   */
  formatDateForESSL(dateInput) {
    const date = moment(dateInput)

    if (!date.isValid()) {
      throw new Error(`Invalid date: ${dateInput}`)
    }

    // eSSL expects format like "27-Mar-2025"
    return date.format("DD-MMM-YYYY")
  }
}

module.exports = ESSLService
