const logger = require("./logger")

class HealthMonitor {
  constructor() {
    this.startTime = new Date()
    this.lastSyncTime = null
    this.syncCount = 0
    this.successfulSyncs = 0
    this.failedSyncs = 0
    this.errors = []
    this.maxErrors = 100 // Keep last 100 errors

    this.metrics = {
      totalRecordsProcessed: 0,
      totalRecordsSynced: 0,
      totalRecordsFailed: 0,
      averageSyncDuration: 0,
      syncDurations: [],
    }

    this.status = "starting"
  }

  recordSyncStart() {
    this.syncCount++
    this.status = "syncing"
  }

  recordSyncEnd(success, results = null) {
    if (success) {
      this.successfulSyncs++
      this.lastSyncTime = new Date()
      this.status = "healthy"

      if (results) {
        this.metrics.totalRecordsProcessed += results.synced + results.failed
        this.metrics.totalRecordsSynced += results.synced
        this.metrics.totalRecordsFailed += results.failed
      }
    } else {
      this.failedSyncs++
      this.status = "error"
    }
  }

  recordError(error) {
    const errorRecord = {
      timestamp: new Date(),
      message: error.message,
      stack: error.stack,
      type: error.constructor.name,
    }

    this.errors.unshift(errorRecord)

    // Keep only last N errors
    if (this.errors.length > this.maxErrors) {
      this.errors = this.errors.slice(0, this.maxErrors)
    }

    logger.error("Error recorded in health monitor", errorRecord)
  }

  recordSyncDuration(duration) {
    this.metrics.syncDurations.push(duration)

    // Keep only last 100 durations for average calculation
    if (this.metrics.syncDurations.length > 100) {
      this.metrics.syncDurations.shift()
    }

    // Calculate average
    const sum = this.metrics.syncDurations.reduce((a, b) => a + b, 0)
    this.metrics.averageSyncDuration = Math.round(sum / this.metrics.syncDurations.length)
  }

  getHealth() {
    const uptime = Date.now() - this.startTime.getTime()
    const uptimeHours = (uptime / (1000 * 60 * 60)).toFixed(2)

    const successRate = this.syncCount > 0 ? ((this.successfulSyncs / this.syncCount) * 100).toFixed(2) : 0

    const syncRate =
      this.metrics.totalRecordsProcessed > 0
        ? ((this.metrics.totalRecordsSynced / this.metrics.totalRecordsProcessed) * 100).toFixed(2)
        : 0

    return {
      status: this.status,
      uptime: {
        milliseconds: uptime,
        hours: uptimeHours,
        startTime: this.startTime,
      },
      sync: {
        lastSyncTime: this.lastSyncTime,
        totalSyncs: this.syncCount,
        successfulSyncs: this.successfulSyncs,
        failedSyncs: this.failedSyncs,
        successRate: `${successRate}%`,
      },
      records: {
        totalProcessed: this.metrics.totalRecordsProcessed,
        totalSynced: this.metrics.totalRecordsSynced,
        totalFailed: this.metrics.totalRecordsFailed,
        syncRate: `${syncRate}%`,
      },
      performance: {
        averageSyncDuration: `${this.metrics.averageSyncDuration}ms`,
        recentSyncCount: this.metrics.syncDurations.length,
      },
      errors: {
        count: this.errors.length,
        recent: this.errors.slice(0, 5).map((e) => ({
          timestamp: e.timestamp,
          message: e.message,
          type: e.type,
        })),
      },
    }
  }

  getStatus() {
    return this.status
  }

  isHealthy() {
    // Consider healthy if:
    // 1. Status is not 'error'
    // 2. Last sync was within last 10 minutes (if any syncs have occurred)
    // 3. Success rate is above 50%

    if (this.status === "error") {
      return false
    }

    if (this.lastSyncTime) {
      const timeSinceLastSync = Date.now() - this.lastSyncTime.getTime()
      const tenMinutes = 10 * 60 * 1000

      if (timeSinceLastSync > tenMinutes) {
        return false
      }
    }

    if (this.syncCount > 0) {
      const successRate = (this.successfulSyncs / this.syncCount) * 100
      if (successRate < 50) {
        return false
      }
    }

    return true
  }

  reset() {
    this.syncCount = 0
    this.successfulSyncs = 0
    this.failedSyncs = 0
    this.errors = []
    this.metrics = {
      totalRecordsProcessed: 0,
      totalRecordsSynced: 0,
      totalRecordsFailed: 0,
      averageSyncDuration: 0,
      syncDurations: [],
    }
    logger.info("Health monitor statistics reset")
  }
}

module.exports = HealthMonitor
