const express = require("express")
const router = express.Router()

module.exports = (syncService, zohoService, healthMonitor) => {
  // Health check endpoint
  router.get("/health", (req, res) => {
    const health = healthMonitor.getHealth()
    const statusCode = healthMonitor.isHealthy() ? 200 : 503

    res.status(statusCode).json({
      status: health.status,
      healthy: healthMonitor.isHealthy(),
      ...health,
    })
  })

  // Detailed status endpoint
  router.get("/status", (req, res) => {
    const status = syncService.getStatus()
    res.json(status)
  })

  // Statistics endpoint
  router.get("/stats", (req, res) => {
    const health = healthMonitor.getHealth()
    const syncStatus = syncService.getStatus()

    res.json({
      health: health,
      sync: syncStatus,
      timestamp: new Date(),
    })
  })

  // OAuth authorization endpoint
  router.get("/oauth/authorize", (req, res) => {
    const authUrl = zohoService.getAuthorizationUrl()
    res.redirect(authUrl)
  })

  // OAuth callback endpoint
  router.get("/oauth/callback", async (req, res) => {
    const { code, error } = req.query

    if (error) {
      return res.status(400).json({
        success: false,
        error: "Authorization failed",
        details: error,
      })
    }

    if (!code) {
      return res.status(400).json({
        success: false,
        error: "No authorization code received",
      })
    }

    try {
      const tokenInfo = await zohoService.exchangeCodeForToken(code)

      res.json({
        success: true,
        message: "Authorization successful! Tokens have been saved.",
        tokenInfo: {
          expiresAt: tokenInfo.expiresAt,
          scope: tokenInfo.scope,
        },
      })
    } catch (error) {
      res.status(500).json({
        success: false,
        error: "Failed to exchange authorization code",
        details: error.message,
      })
    }
  })

  // Test eSSL connection
  router.get("/test/essl", async (req, res) => {
    try {
      const result = await syncService.esslService.testConnection()
      res.json(result)
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message,
      })
    }
  })

  // Test Zoho connection
  router.get("/test/zoho", async (req, res) => {
    try {
      const result = await zohoService.testConnection()
      res.json(result)
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message,
      })
    }
  })

  // Manual sync trigger (for testing)
  router.post("/sync/trigger", async (req, res) => {
    res.json({
      success: true,
      message: "Manual sync is not implemented. Service runs automatically.",
    })
  })

  // Reset statistics
  router.post("/stats/reset", (req, res) => {
    healthMonitor.reset()
    syncService.resetStats()

    res.json({
      success: true,
      message: "Statistics reset successfully",
    })
  })

  // Root endpoint
  router.get("/", (req, res) => {
    res.json({
      service: "eSSL to Zoho People Sync",
      version: "2.0.0",
      status: healthMonitor.getStatus(),
      endpoints: {
        health: "/health",
        status: "/status",
        stats: "/stats",
        oauth: "/oauth/authorize",
        testEssl: "/test/essl",
        testZoho: "/test/zoho",
      },
    })
  })

  return router
}
