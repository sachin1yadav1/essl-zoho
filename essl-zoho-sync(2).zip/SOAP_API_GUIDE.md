# eSSL SOAP API Implementation Guide

## Overview

This document explains how the eSSL SOAP API integration works and common issues you might encounter.

## How It Works

### 1. SOAP Request Structure

The eSSL eBioServerNew uses SOAP 1.1 protocol. Each request follows this structure:

\`\`\`xml
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
               xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
               xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <MethodName xmlns="http://tempuri.org/">
      <UserName>your_username</UserName>
      <Password>your_password</Password>
       Additional parameters 
    </MethodName>
  </soap:Body>
</soap:Envelope>
\`\`\`

### 2. SOAP Response Structure

Responses follow this format:

\`\`\`xml
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <MethodNameResponse xmlns="http://tempuri.org/">
      <MethodNameResult>result_data_here</MethodNameResult>
    </MethodNameResponse>
  </soap:Body>
</soap:Envelope>
\`\`\`

## Available API Methods

### 1. GetDeviceLogs

**Purpose:** Fetch punch transactions for a specific date

**Parameters:**
- `UserName`: eSSL username
- `Password`: eSSL password
- `Location`: Location code (empty for all locations)
- `LogDate`: Date in format `DD-MMM-YYYY` (e.g., "27-Mar-2025")

**Response Format:**
\`\`\`
DateTime,EmployeeCode,DeviceName,Location,Direction;DateTime,EmployeeCode,DeviceName,Location,Direction;
\`\`\`

**Example:**
\`\`\`
27-Mar-2025 09:15:30,EMP001,Main Gate,Office,IN;27-Mar-2025 18:30:45,EMP001,Main Gate,Office,OUT;
\`\`\`

### 2. GetDeviceLogsByLogId

**Purpose:** Fetch transactions incrementally using log ID (recommended for continuous sync)

**Parameters:**
- `UserName`: eSSL username
- `Password`: eSSL password
- `Location`: Location code (empty for all locations)
- `LogId`: Last log ID received (start with "0" for first fetch)
- `LogCount`: Number of records to fetch (default: 100)

**Response Format:** Same as GetDeviceLogs

**Why Use This:**
- More efficient than date-based queries
- Automatically gets only new records
- Prevents duplicate processing

### 3. GetDeviceList

**Purpose:** Get list of all connected devices

**Parameters:**
- `UserName`: eSSL username
- `Password`: eSSL password
- `Location`: Location code (empty for all locations)

**Response Format:**
\`\`\`
SerialNumber,DeviceName,Location,Status;SerialNumber,DeviceName,Location,Status;
\`\`\`

### 4. GetEmployeeCodes

**Purpose:** Get all employee codes from the system

**Parameters:**
- `UserName`: eSSL username
- `Password`: eSSL password
- `EmployeeCode`: Empty string to get all codes

**Response Format:**
\`\`\`
CODE1;CODE2;CODE3;CODE4;
\`\`\`

### 5. GetEmployeeDetails

**Purpose:** Get detailed information for a specific employee

**Parameters:**
- `UserName`: eSSL username
- `Password`: eSSL password
- `EmployeeCode`: Specific employee code

**Response Format:**
\`\`\`
EmployeeCode,EmployeeName,CardNumber,Location,Role
\`\`\`

## Common Issues and Solutions

### Issue 1: Connection Timeout

**Symptoms:**
- Error: "ECONNREFUSED" or "timeout of Xms exceeded"

**Solutions:**
1. Check if eBioServerNew is running
2. Verify the URL format: `http://IP:PORT/webservice.asmx`
3. Check firewall settings
4. Increase timeout in `.env`: `ESSL_TIMEOUT=30000`

### Issue 2: Authentication Failed

**Symptoms:**
- Error: "Invalid username or password"
- SOAP Fault response

**Solutions:**
1. Verify credentials in eBioServerNew application
2. Check if user has API access permissions
3. Ensure no special characters in password that need escaping

### Issue 3: Empty Response

**Symptoms:**
- No error but empty results
- `Retrieved 0 transactions`

**Solutions:**
1. Check if devices are connected to eBioServerNew
2. Verify location code (try empty string for all locations)
3. Check date format: Must be `DD-MMM-YYYY` (e.g., "27-Mar-2025")
4. Ensure employees have punched on that date

### Issue 4: XML Parsing Error

**Symptoms:**
- Error: "Non-whitespace before first tag"
- XML parsing failed

**Solutions:**
1. Check if eBioServerNew is returning HTML error page instead of SOAP
2. Verify the webservice URL ends with `/webservice.asmx`
3. Check eBioServerNew logs for errors

### Issue 5: Date Format Issues

**Symptoms:**
- No data returned for valid dates
- Date parsing errors

**Solutions:**
1. eSSL uses format: `DD-MMM-YYYY` (e.g., "27-Mar-2025")
2. Month must be 3-letter abbreviation (Jan, Feb, Mar, etc.)
3. Use the config setting: `ESSL_DATE_FORMAT=DD-MMM-YYYY`

## Testing the API

### Step 1: Test Connection

\`\`\`bash
npm run test-essl
\`\`\`

This will:
- Connect to eSSL service
- List all devices
- Show employee count

### Step 2: Test Employee Fetch

\`\`\`bash
npm run fetch-essl-employees
\`\`\`

This will:
- Fetch all employee codes
- Get details for each employee
- Save to `essl-employees.json`

### Step 3: Test Real-Time Punches

\`\`\`bash
npm run watch-punches
\`\`\`

This will:
- Monitor for new punches in real-time
- Display employee code, name, and punch time
- Show sync status to Zoho

## Date Format Reference

eSSL uses specific date formats:

| Format | Example | Usage |
|--------|---------|-------|
| DD-MMM-YYYY | 27-Mar-2025 | GetDeviceLogs LogDate parameter |
| DD-MMM-YYYY HH:mm:ss | 27-Mar-2025 09:15:30 | Transaction DateTime in response |

## Response Parsing

### Transaction Response

Raw response:
\`\`\`
27-Mar-2025 09:15:30,EMP001,Main Gate,Office,IN;27-Mar-2025 18:30:45,EMP001,Main Gate,Office,OUT;
\`\`\`

Parsed to:
\`\`\`javascript
[
  {
    DateTime: "27-Mar-2025 09:15:30",
    PunchDate: "27-Mar-2025",
    PunchTime: "09:15:30",
    EmployeeCode: "EMP001",
    DeviceName: "Main Gate",
    Location: "Office",
    Direction: "IN",
    RawData: "27-Mar-2025 09:15:30,EMP001,Main Gate,Office,IN"
  },
  {
    DateTime: "27-Mar-2025 18:30:45",
    PunchDate: "27-Mar-2025",
    PunchTime: "18:30:45",
    EmployeeCode: "EMP001",
    DeviceName: "Main Gate",
    Location: "Office",
    Direction: "OUT",
    RawData: "27-Mar-2025 18:30:45,EMP001,Main Gate,Office,OUT"
  }
]
\`\`\`

## Best Practices

1. **Use GetDeviceLogsByLogId for continuous sync**
   - More efficient than date-based queries
   - Automatically handles incremental updates

2. **Handle empty responses gracefully**
   - Empty string means no data, not an error
   - Don't retry immediately on empty responses

3. **Implement proper error handling**
   - Network errors: Retry with exponential backoff
   - Authentication errors: Stop and alert
   - Parse errors: Log raw response for debugging

4. **Monitor API health**
   - Track request count and success rate
   - Alert on high failure rates
   - Log response times

5. **Respect API limits**
   - Don't make too many requests per second
   - Use appropriate polling intervals
   - Batch requests when possible

## Troubleshooting Commands

\`\`\`bash
# Test basic connectivity
curl -X POST http://YOUR_IP:PORT/webservice.asmx

# Test SOAP request (replace with your credentials)
curl -X POST http://YOUR_IP:PORT/webservice.asmx \
  -H "Content-Type: text/xml; charset=utf-8" \
  -H "SOAPAction: http://tempuri.org/GetDeviceList" \
  -d '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetDeviceList xmlns="http://tempuri.org/">
      <UserName>admin</UserName>
      <Password>password</Password>
      <Location></Location>
    </GetDeviceList>
  </soap:Body>
</soap:Envelope>'
\`\`\`

## Support

If you encounter issues not covered here:

1. Check eBioServerNew logs
2. Enable debug logging: `LOG_LEVEL=debug`
3. Check `logs/error.log` for detailed error messages
4. Verify network connectivity between server and eBioServerNew
