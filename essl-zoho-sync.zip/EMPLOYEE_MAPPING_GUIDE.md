# Employee Mapping Guide

This guide explains how to find eSSL employee codes and Zoho employee IDs, then map them together.

## Overview

The sync service requires a mapping between:
- **eSSL Employee Code**: The employee ID in your eSSL biometric system
- **Zoho Employee ID**: The employee ID in Zoho People

## Step 1: Find eSSL Employee Codes

### Method 1: Using the Fetch Script (Recommended)

Run the automated script to fetch all employees from eSSL:

\`\`\`bash
npm run fetch-essl-employees
\`\`\`

This will:
- Connect to your eSSL system
- Fetch all employee codes and details
- Save data to `essl-employees.json`
- Generate a mapping template in `employee-mapping-template.js`

**Output Example:**
\`\`\`
Code           Name                          Card Number    Location
----------------------------------------------------------------------
E001           John Doe                      1234567890     HQ
E002           Jane Smith                    1234567891     Branch1
E003           Bob Johnson                   1234567892     HQ
\`\`\`

### Method 2: From eSSL eBioServerNew Application

1. Open eBioServerNew application
2. Go to **Employee Management**
3. View the employee list
4. Note down the **Employee Code** for each person

### Method 3: From Device Display

When an employee punches:
- The device shows their employee code
- Note it down for mapping

## Step 2: Find Zoho Employee IDs

### Method 1: Using the Fetch Script (Recommended)

Run the automated script to fetch all employees from Zoho:

\`\`\`bash
npm run fetch-zoho-employees
\`\`\`

This will:
- Connect to Zoho People API
- Fetch all employee records
- Save data to `zoho-employees.json`
- Display employee IDs and names

**Output Example:**
\`\`\`
Zoho ID              Name                          Email
----------------------------------------------------------------------
1234567890           John Doe                      john@company.com
1234567891           Jane Smith                    jane@company.com
1234567892           Bob Johnson                   bob@company.com
\`\`\`

### Method 2: From Zoho People Web Interface

1. Login to Zoho People
2. Go to **Employees** section
3. Click on an employee
4. Check the URL: `https://people.zoho.com/...?empId=1234567890`
5. The number after `empId=` is the Zoho Employee ID

### Method 3: Using Zoho API

\`\`\`bash
curl -X GET "https://people.zoho.com/people/api/forms/employee/getRecords" \\
  -H "Authorization: Zoho-oauthtoken YOUR_ACCESS_TOKEN"
\`\`\`

## Step 3: Create the Mapping

### Option A: Manual Mapping

Edit `src/config/employee-mapping.js`:

\`\`\`javascript
module.exports = {
  // eSSL Code: Zoho ID
  'E001': '1234567890',  // John Doe
  'E002': '1234567891',  // Jane Smith
  'E003': '1234567892',  // Bob Johnson
};
\`\`\`

### Option B: Using Generated Template

1. After running `npm run fetch-essl-employees`, you'll have `employee-mapping-template.js`
2. After running `npm run fetch-zoho-employees`, you'll have `zoho-employees.json`
3. Match employees by name
4. Replace `ZOHO_ID_HERE` with actual Zoho IDs
5. Copy to `src/config/employee-mapping.js`

## Step 4: Verify the Mapping

### Test with Watch Script

Monitor real-time punches to verify mapping:

\`\`\`bash
npm run watch-punches
\`\`\`

When employees punch, you'll see:
\`\`\`
✓ eSSL: E001 | Name: John Doe | Time: 2025-01-15 09:30:00 | Zoho: 1234567890
✗ eSSL: E999 | Name: Unknown | Time: 2025-01-15 09:31:00 | Zoho: NOT_MAPPED
\`\`\`

- ✓ = Employee is mapped correctly
- ✗ = Employee is not mapped (needs to be added)

### Check Logs

After starting the sync service, check `logs/punch.log`:

\`\`\`bash
tail -f logs/punch.log
\`\`\`

You'll see detailed logs like:
\`\`\`
2025-01-15 09:30:15 | ✓ SUCCESS | eSSL: E001 | Name: John Doe | Zoho: 1234567890 | Time: 2025-01-15 09:30:00
2025-01-15 09:31:20 | ✗ FAILED | eSSL: E999 | Name: Unknown | Zoho: NOT_MAPPED | Time: 2025-01-15 09:31:00
\`\`\`

## Troubleshooting

### Employee Not Syncing

**Problem:** Punches are recorded in eSSL but not appearing in Zoho

**Solutions:**
1. Check if employee is mapped in `employee-mapping.js`
2. Verify eSSL code matches exactly (case-sensitive)
3. Verify Zoho ID is correct
4. Check logs: `tail -f logs/punch.log`

### Wrong Employee Syncing

**Problem:** Punch is syncing to wrong employee in Zoho

**Solutions:**
1. Double-check the mapping in `employee-mapping.js`
2. Verify Zoho Employee ID is correct
3. Re-fetch employee lists to ensure accuracy

### Employee Code Not Found

**Problem:** eSSL employee code not appearing in fetch script

**Solutions:**
1. Ensure employee is enrolled in eSSL device
2. Check `ESSL_LOCATION_CODE` in `.env` (empty = all locations)
3. Verify employee is active in eBioServerNew

### Zoho Employee ID Not Found

**Problem:** Zoho employee not appearing in fetch script

**Solutions:**
1. Ensure employee exists in Zoho People
2. Check OAuth scope includes `ZohoPeople.forms.READ`
3. Verify employee status is "Active" in Zoho

## Time-Based Sync Behavior

The system automatically adjusts sync frequency based on time:

- **Before 8am**: Every 5 minutes (low activity)
- **8am - 11am**: Every 15 seconds (morning arrivals, late punches)
- **11am - 2pm**: Every 30 seconds (lunch time)
- **2pm - 6pm**: Every 15 seconds (afternoon activity, early departures)
- **After 6pm**: Every 30 seconds (evening activity)

This ensures:
- Late arrivals after 10am are synced within 15 seconds
- Lunch break punches are captured quickly
- System is efficient during low-activity periods

## Quick Reference

| Task | Command |
|------|---------|
| Fetch eSSL employees | `npm run fetch-essl-employees` |
| Fetch Zoho employees | `npm run fetch-zoho-employees` |
| Watch real-time punches | `npm run watch-punches` |
| View punch logs | `tail -f logs/punch.log` |
| Test eSSL connection | `npm run test-essl` |
| Test Zoho connection | `npm run test-zoho` |

## Example Workflow

\`\`\`bash
# 1. Fetch employees from both systems
npm run fetch-essl-employees
npm run fetch-zoho-employees

# 2. Edit the mapping file
nano src/config/employee-mapping.js

# 3. Test the mapping
npm run watch-punches

# 4. Start the sync service
npm start

# 5. Monitor logs
tail -f logs/punch.log
\`\`\`

## Support

If you encounter issues:
1. Check logs in `logs/` directory
2. Run test scripts to verify connections
3. Use watch-punches to monitor real-time activity
4. Review this guide for troubleshooting steps
\`\`\`

```json file="" isHidden
