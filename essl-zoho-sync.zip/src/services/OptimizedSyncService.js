const moment = require("moment")
const config = require("../config/config")
const employeeMapping = require("../config/employee-mapping")
const logger = require("../utils/logger")

class OptimizedSyncService {
  constructor(esslService, zohoService, healthMonitor) {
    this.esslService = esslService
    this.zohoService = zohoService
    this.healthMonitor = healthMonitor

    this.lastSyncTime = config.sync.lastSyncTime
    this.currentInterval = config.essl.baseInterval
    this.emptyPollsCount = 0
    this.consecutiveErrors = 0
    this.isRunning = false

    this.syncStats = {
      totalProcessed: 0,
      successful: 0,
      failed: 0,
      lastSync: null,
      averageProcessingTime: 0,
    }

    this.timeBasedIntervals = {
      beforeWorkHours: config.essl.maxInterval, // 5 minutes before 8am
      morningPeak: config.essl.minInterval, // 15 seconds 8am-11am
      midDay: 30000, // 30 seconds 11am-2pm
      afternoonPeak: config.essl.minInterval, // 15 seconds 2pm-6pm
      afterHours: config.essl.baseInterval, // 30 seconds after 6pm
    }

    this.peakHours = {
      morning: { start: 8, end: 10 },
      evening: { start: 17, end: 19 },
    }
  }

  async start() {
    this.isRunning = true
    logger.success(`🚀 Starting optimized sync service`)
    logger.info(`Initial interval: ${this.currentInterval}ms, Adaptive: Enabled`)

    await this.syncCycle()
  }

  async syncCycle() {
    if (!this.isRunning) return

    try {
      this.healthMonitor.recordSyncStart()
      const cycleStart = Date.now()

      const dateFormat = config.essl.dateFormat || "YYYY-MM-DD HH:mm:ss"

      if (!this.lastSyncTime || this.lastSyncTime.length < 5) {
        const minutes = Number.parseInt(config.essl.initialSyncWindowMinutes) || 120
        this.lastSyncTime = moment().subtract(minutes, "minutes").format(dateFormat)
        logger.info(`Initial backfill window: ${minutes} minutes`)
      }

      const currentTime = moment().format(dateFormat)
      logger.debug(`Sync cycle started from ${this.lastSyncTime} to ${currentTime}`)

      const transactions = await this.esslService.getTransactions(this.lastSyncTime, currentTime)
      let syncResults = { synced: 0, failed: 0 }

      if (transactions.length === 0) {
        logger.debug("No new transactions found")
        this.handleEmptyPoll()
      } else {
        logger.info(`Processing ${transactions.length} new transactions`)
        syncResults = await this.processTransactions(transactions)
        this.handleSuccessfulPoll()
      }

      this.lastSyncTime = currentTime
      this.syncStats.lastSync = new Date()

      const cycleDuration = Date.now() - cycleStart
      this.healthMonitor.recordSyncEnd(true, syncResults)

      logger.syncStats(syncResults.synced, syncResults.failed, transactions.length, cycleDuration)
    } catch (error) {
      this.healthMonitor.recordSyncEnd(false)
      this.healthMonitor.recordError(error)
      this.handleSyncError(error)
    }

    if (this.isRunning) {
      this.currentInterval = this.calculateIntervalByTime()
      logger.debug(`Next sync in ${this.currentInterval}ms (${this.currentInterval / 1000}s)`)
      setTimeout(() => this.syncCycle(), this.currentInterval)
    }
  }

  async processTransactions(transactions) {
    const results = { synced: 0, failed: 0 }
    const batchSize = this.calculateBatchSize(transactions.length)

    for (let i = 0; i < transactions.length; i += batchSize) {
      const batch = transactions.slice(i, i + batchSize)
      const batchResults = await this.processBatch(batch)

      results.synced += batchResults.synced
      results.failed += batchResults.failed

      if (i + batchSize < transactions.length) {
        await this.delay(config.zoho.rateLimitDelay)
      }
    }

    return results
  }

  async processBatch(batch) {
    const results = { synced: 0, failed: 0 }
    const promises = []

    for (const transaction of batch) {
      promises.push(this.processSingleTransaction(transaction))
    }

    const batchResults = await Promise.allSettled(promises)

    batchResults.forEach((result) => {
      if (result.status === "fulfilled" && result.value) {
        results.synced++
      } else {
        results.failed++
      }
    })

    return results
  }

  async processSingleTransaction(transaction) {
    try {
      const punchData = this.transformTransaction(transaction)

      if (!punchData) {
        logger.warn(`Skipping invalid transaction: ${JSON.stringify(transaction)}`)
        return false
      }

      const result = await this.zohoService.sendAttendance(punchData)

      if (result.success) {
        this.syncStats.successful++
        logger.punchSync(punchData.esslEmpCode, punchData.employeeName, punchData.zohoEmpId, punchData.punchTime, true)
        return true
      } else {
        this.syncStats.failed++
        logger.punchSync(
          punchData.esslEmpCode,
          punchData.employeeName,
          punchData.zohoEmpId,
          punchData.punchTime,
          false,
          result.error,
        )
        return false
      }
    } catch (error) {
      this.syncStats.failed++
      logger.error(`Error processing transaction: ${error.message}`)
      return false
    }
  }

  transformTransaction(transaction) {
    try {
      const esslEmpCode = transaction.EmployeeCode || transaction.employeeCode
      const zohoEmpId = employeeMapping[esslEmpCode]

      if (!zohoEmpId) {
        logger.warn(`No Zoho mapping found for eSSL employee: ${esslEmpCode}`)
        return null
      }

      const punchTime = this.formatTimestamp(
        transaction.PunchDate || transaction.punchDate,
        transaction.PunchTime || transaction.punchTime,
      )

      if (!punchTime) {
        logger.warn(`Invalid timestamp for employee ${esslEmpCode}`)
        return null
      }

      return {
        esslEmpCode: esslEmpCode,
        employeeName: transaction.EmployeeName || "Unknown",
        zohoEmpId: zohoEmpId,
        punchTime: punchTime,
        comments: `Biometric: ${transaction.DeviceName || transaction.MachineName || "eSSL Device"}`,
        deviceId: transaction.DeviceID || transaction.MachineNo,
        rawData: transaction,
      }
    } catch (error) {
      logger.error(`Error transforming transaction: ${error.message}`)
      return null
    }
  }

  formatTimestamp(dateStr, timeStr) {
    try {
      let timestamp

      if (dateStr && timeStr) {
        timestamp = `${dateStr} ${timeStr}`
      } else if (dateStr && dateStr.includes(" ")) {
        timestamp = dateStr
      } else {
        return null
      }

      const parsed = moment(timestamp, [
        "YYYY-MM-DD HH:mm:ss",
        "DD/MM/YYYY HH:mm:ss",
        "MM/DD/YYYY HH:mm:ss",
        "YYYY/MM/DD HH:mm:ss",
      ])

      if (!parsed.isValid()) {
        return null
      }

      return parsed.format("YYYY-MM-DD HH:mm:ss")
    } catch (error) {
      logger.error(`Error formatting timestamp: ${error.message}`)
      return null
    }
  }

  calculateIntervalByTime() {
    const currentHour = new Date().getHours()

    // Before work hours (before 8am)
    if (currentHour < 8) {
      return this.timeBasedIntervals.beforeWorkHours
    }

    // Morning peak (8am - 11am) - Most frequent for late arrivals
    if (currentHour >= 8 && currentHour < 11) {
      return this.timeBasedIntervals.morningPeak
    }

    // Mid-day (11am - 2pm) - Lunch time punches
    if (currentHour >= 11 && currentHour < 14) {
      return this.timeBasedIntervals.midDay
    }

    // Afternoon peak (2pm - 6pm) - Frequent for early departures
    if (currentHour >= 14 && currentHour < 18) {
      return this.timeBasedIntervals.afternoonPeak
    }

    // After hours (after 6pm)
    return this.timeBasedIntervals.afterHours
  }

  calculateBatchSize(transactionCount) {
    if (transactionCount <= 10) return 1
    if (transactionCount <= 50) return 5
    return config.sync.batchSize
  }

  handleEmptyPoll() {
    this.emptyPollsCount++
    this.consecutiveErrors = 0
  }

  handleSuccessfulPoll() {
    this.emptyPollsCount = 0
    this.consecutiveErrors = 0
  }

  handleSyncError(error) {
    this.consecutiveErrors++
    this.emptyPollsCount = 0

    const newInterval = Math.min(
      config.essl.maxInterval,
      config.essl.baseInterval * Math.pow(config.sync.backoffFactor, this.consecutiveErrors),
    )

    if (newInterval !== this.currentInterval) {
      logger.warn(`🚨 Errors detected - increasing interval to ${newInterval}ms`)
      this.currentInterval = newInterval
    }

    logger.error(`Sync error: ${error.message}`)
  }

  adjustIntervalBasedOnTime() {
    const currentHour = new Date().getHours()
    const isPeakHour =
      (currentHour >= this.peakHours.morning.start && currentHour < this.peakHours.morning.end) ||
      (currentHour >= this.peakHours.evening.start && currentHour < this.peakHours.evening.end)

    if (isPeakHour && this.currentInterval > config.essl.minInterval) {
      this.currentInterval = Math.max(config.essl.minInterval, this.currentInterval / 2)
    }
  }

  delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }

  stop() {
    this.isRunning = false
    logger.info("🛑 Sync service stopped")
  }

  getStatus() {
    const currentHour = new Date().getHours()
    let timeZone = "After Hours"

    if (currentHour >= 8 && currentHour < 11) timeZone = "Morning Peak (8am-11am)"
    else if (currentHour >= 11 && currentHour < 14) timeZone = "Mid-Day (11am-2pm)"
    else if (currentHour >= 14 && currentHour < 18) timeZone = "Afternoon Peak (2pm-6pm)"
    else if (currentHour < 8) timeZone = "Before Work Hours"

    return {
      isRunning: this.isRunning,
      currentInterval: this.currentInterval,
      currentIntervalSeconds: (this.currentInterval / 1000).toFixed(1),
      timeZone: timeZone,
      lastSyncTime: this.lastSyncTime,
      syncStats: { ...this.syncStats },
      performance: {
        emptyPollsCount: this.emptyPollsCount,
        consecutiveErrors: this.consecutiveErrors,
      },
      services: {
        essl: this.esslService.getStats(),
        zoho: this.zohoService.getStats(),
      },
    }
  }

  resetStats() {
    this.syncStats = {
      totalProcessed: 0,
      successful: 0,
      failed: 0,
      lastSync: this.syncStats.lastSync,
      averageProcessingTime: 0,
    }
  }
}

module.exports = OptimizedSyncService
