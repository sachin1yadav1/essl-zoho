const soap = require("soap")
const xml2js = require("xml2js")
const config = require("../config/config")
const logger = require("../utils/logger")

class ESSLService {
  constructor() {
    this.url = config.essl.webserviceUrl
    this.username = config.essl.username
    this.password = config.essl.password
    this.locationCode = config.essl.locationCode
    this.client = null
    this.requestCount = 0
    this.failedRequests = 0
  }

  /**
   * Initialize SOAP client
   */
  async initialize() {
    try {
      logger.info(`Connecting to eSSL SOAP service: ${this.url}`)

      this.client = await soap.createClientAsync(this.url, {
        wsdl_options: {
          timeout: config.essl.timeout,
        },
      })

      logger.success("eSSL SOAP client initialized successfully")
      return true
    } catch (error) {
      logger.error(`Failed to initialize eSSL SOAP client: ${error.message}`)
      throw error
    }
  }

  /**
   * Get device logs (punch transactions) between date range
   */
  async getTransactions(fromDate, toDate) {
    this.requestCount++

    try {
      if (!this.client) {
        await this.initialize()
      }

      const args = {
        UserName: this.username,
        Password: this.password,
        Location: this.locationCode,
        LogDate: fromDate, // eSSL uses single date parameter for range queries
      }

      logger.debug(`Fetching transactions from ${fromDate} to ${toDate}`)

      const [result] = await this.client.GetDeviceLogsAsync(args)

      if (!result || !result.GetDeviceLogsResult) {
        logger.debug("No transactions returned from eSSL")
        return []
      }

      const transactions = this.parseTransactionResult(result.GetDeviceLogsResult)

      // Filter transactions within the date range
      const filtered = this.filterByDateRange(transactions, fromDate, toDate)

      logger.debug(`Retrieved ${filtered.length} transactions from eSSL`)
      return filtered
    } catch (error) {
      this.failedRequests++
      logger.error(`Failed to get transactions: ${error.message}`)
      throw error
    }
  }

  /**
   * Get device logs by log ID (for incremental sync)
   */
  async getTransactionsByLogId(lastLogId, logCount = 100) {
    this.requestCount++

    try {
      if (!this.client) {
        await this.initialize()
      }

      const args = {
        UserName: this.username,
        Password: this.password,
        Location: this.locationCode,
        LogId: lastLogId.toString(),
        LogCount: logCount.toString(),
      }

      logger.debug(`Fetching transactions from log ID ${lastLogId}`)

      const [result] = await this.client.GetDeviceLogsByLogIdAsync(args)

      if (!result || !result.GetDeviceLogsByLogIdResult) {
        return []
      }

      const transactions = this.parseTransactionResult(result.GetDeviceLogsByLogIdResult)
      logger.debug(`Retrieved ${transactions.length} transactions by log ID`)

      return transactions
    } catch (error) {
      this.failedRequests++
      logger.error(`Failed to get transactions by log ID: ${error.message}`)
      throw error
    }
  }

  /**
   * Get list of all devices
   */
  async getDevices() {
    try {
      if (!this.client) {
        await this.initialize()
      }

      const args = {
        UserName: this.username,
        Password: this.password,
        Location: this.locationCode,
      }

      const [result] = await this.client.GetDeviceListAsync(args)

      if (!result || !result.GetDeviceListResult) {
        return []
      }

      const devices = this.parseDeviceResult(result.GetDeviceListResult)
      logger.info(`Retrieved ${devices.length} devices from eSSL`)

      return devices
    } catch (error) {
      logger.error(`Failed to get devices: ${error.message}`)
      throw error
    }
  }

  /**
   * Get employee details
   */
  async getEmployee(employeeCode) {
    try {
      if (!this.client) {
        await this.initialize()
      }

      const args = {
        UserName: this.username,
        Password: this.password,
        EmployeeCode: employeeCode,
      }

      const [result] = await this.client.GetEmployeeDetailsAsync(args)

      if (!result || !result.GetEmployeeDetailsResult) {
        return null
      }

      return this.parseEmployeeResult(result.GetEmployeeDetailsResult)
    } catch (error) {
      logger.error(`Failed to get employee ${employeeCode}: ${error.message}`)
      return null
    }
  }

  /**
   * Get all employee codes
   */
  async getEmployeeCodes() {
    try {
      if (!this.client) {
        await this.initialize()
      }

      const args = {
        UserName: this.username,
        Password: this.password,
        EmployeeCode: "", // Empty to get all
      }

      const [result] = await this.client.GetEmployeeCodesAsync(args)

      if (!result || !result.GetEmployeeCodesResult) {
        return []
      }

      const codes = this.parseEmployeeCodesResult(result.GetEmployeeCodesResult)
      logger.info(`Retrieved ${codes.length} employee codes from eSSL`)

      return codes
    } catch (error) {
      logger.error(`Failed to get employee codes: ${error.message}`)
      throw error
    }
  }

  /**
   * Parse transaction result string
   * Format: "DateTime,EmployeeCode,DeviceName,Location,Direction;..."
   */
  parseTransactionResult(resultString) {
    if (!resultString || resultString.trim() === "") {
      return []
    }

    try {
      const transactions = []
      const records = resultString.split(";").filter((r) => r.trim())

      for (const record of records) {
        const fields = record.split(",").map((f) => f.trim())

        if (fields.length >= 5) {
          transactions.push({
            PunchDate: fields[0].split(" ")[0],
            PunchTime: fields[0].split(" ")[1] || "00:00:00",
            EmployeeCode: fields[1],
            DeviceName: fields[2],
            Location: fields[3],
            Direction: fields[4],
            RawData: record,
          })
        }
      }

      return transactions
    } catch (error) {
      logger.error(`Failed to parse transaction result: ${error.message}`)
      return []
    }
  }

  /**
   * Parse device result string
   */
  parseDeviceResult(resultString) {
    if (!resultString || resultString.trim() === "") {
      return []
    }

    try {
      const devices = []
      const records = resultString.split(";").filter((r) => r.trim())

      for (const record of records) {
        const fields = record.split(",").map((f) => f.trim())

        if (fields.length >= 3) {
          devices.push({
            SerialNumber: fields[0],
            DeviceName: fields[1],
            Location: fields[2],
            Status: fields[3] || "Unknown",
          })
        }
      }

      return devices
    } catch (error) {
      logger.error(`Failed to parse device result: ${error.message}`)
      return []
    }
  }

  /**
   * Parse employee result string
   */
  parseEmployeeResult(resultString) {
    if (!resultString || resultString.trim() === "") {
      return null
    }

    try {
      const fields = resultString.split(",").map((f) => f.trim())

      if (fields.length >= 3) {
        return {
          EmployeeCode: fields[0],
          EmployeeName: fields[1],
          CardNumber: fields[2],
          Location: fields[3] || "",
          Role: fields[4] || "",
        }
      }

      return null
    } catch (error) {
      logger.error(`Failed to parse employee result: ${error.message}`)
      return null
    }
  }

  /**
   * Parse employee codes result
   */
  parseEmployeeCodesResult(resultString) {
    if (!resultString || resultString.trim() === "") {
      return []
    }

    try {
      return resultString
        .split(";")
        .map((code) => code.trim())
        .filter((code) => code.length > 0)
    } catch (error) {
      logger.error(`Failed to parse employee codes: ${error.message}`)
      return []
    }
  }

  /**
   * Filter transactions by date range
   */
  filterByDateRange(transactions, fromDate, toDate) {
    const from = new Date(fromDate)
    const to = new Date(toDate)

    return transactions.filter((t) => {
      const punchDateTime = new Date(`${t.PunchDate} ${t.PunchTime}`)
      return punchDateTime >= from && punchDateTime <= to
    })
  }

  /**
   * Test connection to eSSL service
   */
  async testConnection() {
    try {
      logger.info("Testing eSSL connection...")

      await this.initialize()

      // Try to get device list as a connection test
      const devices = await this.getDevices()

      logger.success(`eSSL connection successful. Found ${devices.length} devices.`)

      return {
        success: true,
        message: "Connected to eSSL service",
        deviceCount: devices.length,
        devices: devices,
      }
    } catch (error) {
      logger.error(`eSSL connection test failed: ${error.message}`)
      return {
        success: false,
        error: error.message,
      }
    }
  }

  /**
   * Get service statistics
   */
  getStats() {
    return {
      requestCount: this.requestCount,
      failedRequests: this.failedRequests,
      successRate:
        this.requestCount > 0
          ? (((this.requestCount - this.failedRequests) / this.requestCount) * 100).toFixed(2) + "%"
          : "0%",
      isConnected: this.client !== null,
    }
  }
}

module.exports = ESSLService
