const express = require("express")
const config = require("./config/config")
const logger = require("./utils/logger")
const HealthMonitor = require("./utils/HealthMonitor")
const ESSLService = require("./services/ESSLService")
const ZohoService = require("./services/ZohoService")
const OptimizedSyncService = require("./services/OptimizedSyncService")
const routes = require("./routes")

class Application {
  constructor() {
    this.app = express()
    this.healthMonitor = new HealthMonitor()
    this.esslService = new ESSLService()
    this.zohoService = new ZohoService()
    this.syncService = null
  }

  async initialize() {
    try {
      logger.info("=".repeat(60))
      logger.info("eSSL to Zoho People Sync Service")
      logger.info("=".repeat(60))
      logger.info(`Environment: ${config.env}`)
      logger.info(`Log Level: ${config.logging.level}`)

      // Validate configuration
      this.validateConfiguration()

      // Initialize services
      await this.initializeServices()

      // Setup Express app
      this.setupExpress()

      // Start health check server if enabled
      if (config.health.enabled) {
        this.startHealthServer()
      }

      // Initialize sync service
      this.syncService = new OptimizedSyncService(this.esslService, this.zohoService, this.healthMonitor)

      logger.success("Application initialized successfully")
      return true
    } catch (error) {
      logger.error("Failed to initialize application:", error)
      throw error
    }
  }

  validateConfiguration() {
    const errors = []

    // Check eSSL configuration
    if (!config.essl.webserviceUrl) {
      errors.push("ESSL_WEBSERVICE_URL is not configured")
    }
    if (!config.essl.username) {
      errors.push("ESSL_USERNAME is not configured")
    }
    if (!config.essl.password) {
      errors.push("ESSL_PASSWORD is not configured")
    }

    // Check Zoho OAuth configuration
    if (!config.zoho.oauth.clientId) {
      errors.push("ZOHO_CLIENT_ID is not configured")
    }
    if (!config.zoho.oauth.clientSecret) {
      errors.push("ZOHO_CLIENT_SECRET is not configured")
    }

    if (errors.length > 0) {
      logger.error("Configuration errors found:")
      errors.forEach((err) => logger.error(`  - ${err}`))
      throw new Error("Invalid configuration. Please check your .env file.")
    }

    logger.info("Configuration validated successfully")
  }

  async initializeServices() {
    logger.info("Initializing services...")

    // Initialize eSSL service
    try {
      await this.esslService.initialize()
      logger.success("eSSL service initialized")
    } catch (error) {
      logger.error("Failed to initialize eSSL service:", error.message)
      throw error
    }

    // Check Zoho OAuth tokens
    const tokenInfo = this.zohoService.oauthService.getTokenInfo()
    if (!tokenInfo.hasAccessToken) {
      logger.warn("No Zoho access token found. Please run: npm run oauth-setup")
    } else if (!tokenInfo.isValid) {
      logger.warn("Zoho access token expired. Will attempt to refresh...")
    } else {
      logger.success("Zoho OAuth tokens are valid")
    }
  }

  setupExpress() {
    // Middleware
    this.app.use(express.json())
    this.app.use(express.urlencoded({ extended: true }))

    // Request logging
    this.app.use((req, res, next) => {
      logger.debug(`${req.method} ${req.path}`)
      next()
    })

    // Routes
    this.app.use("/", routes(this.syncService, this.zohoService, this.healthMonitor))

    // Error handling
    this.app.use((err, req, res, next) => {
      logger.error("Express error:", err)
      res.status(500).json({
        error: "Internal server error",
        message: config.isProduction ? "An error occurred" : err.message,
      })
    })
  }

  startHealthServer() {
    this.app.listen(config.health.port, () => {
      logger.success(`Health check server running on port ${config.health.port}`)
      logger.info(`Health dashboard: http://localhost:${config.health.port}/health`)
    })
  }

  async start() {
    try {
      await this.initialize()

      // Start sync service
      logger.info("Starting sync service...")
      await this.syncService.start()

      logger.success("Application started successfully")
      logger.info("Press Ctrl+C to stop")
    } catch (error) {
      logger.error("Failed to start application:", error)
      process.exit(1)
    }
  }

  async stop() {
    logger.info("Stopping application...")

    if (this.syncService) {
      this.syncService.stop()
    }

    logger.info("Application stopped")
    process.exit(0)
  }
}

// Create and start application
const app = new Application()

// Handle graceful shutdown
process.on("SIGINT", () => {
  logger.info("Received SIGINT signal")
  app.stop()
})

process.on("SIGTERM", () => {
  logger.info("Received SIGTERM signal")
  app.stop()
})

// Handle uncaught errors
process.on("uncaughtException", (error) => {
  logger.error("Uncaught exception:", error)
  app.stop()
})

process.on("unhandledRejection", (reason, promise) => {
  logger.error("Unhandled rejection at:", promise, "reason:", reason)
})

// Start the application
app.start()
