const winston = require("winston")
const path = require("path")
const fs = require("fs")
const config = require("../config/config")

const logsDir = path.dirname(config.logging.file)
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true })
}

const consoleFormat = winston.format.combine(
  winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  winston.format.colorize(),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    let metaStr = ""
    if (Object.keys(meta).length > 0) {
      metaStr = "\n" + JSON.stringify(meta, null, 2)
    }
    return `${timestamp} [${level}]: ${message}${metaStr}`
  }),
)

const fileFormat = winston.format.combine(
  winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  winston.format.uncolorize(),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    let metaStr = ""
    if (Object.keys(meta).length > 0) {
      metaStr = " " + JSON.stringify(meta)
    }
    return `${timestamp} [${level}]: ${message}${metaStr}`
  }),
)

const winstonLogger = winston.createLogger({
  level: config.logging.level,
  transports: [
    new winston.transports.Console({
      format: consoleFormat,
    }),
    new winston.transports.File({
      filename: config.logging.file,
      format: fileFormat,
      maxsize: parseSize(config.logging.maxSize),
      maxFiles: config.logging.maxFiles,
    }),
    new winston.transports.File({
      filename: path.join(logsDir, "error.log"),
      level: "error",
      format: fileFormat,
      maxsize: parseSize(config.logging.maxSize),
      maxFiles: config.logging.maxFiles,
    }),
    new winston.transports.File({
      filename: path.join(logsDir, "punch.log"),
      format: fileFormat,
      maxsize: parseSize(config.logging.maxSize),
      maxFiles: config.logging.maxFiles,
    }),
  ],
})

function parseSize(sizeStr) {
  const units = { k: 1024, m: 1024 * 1024, g: 1024 * 1024 * 1024 }
  const match = sizeStr.match(/^(\d+)([kmg])?$/i)
  if (!match) return 10 * 1024 * 1024
  const value = Number.parseInt(match[1])
  const unit = match[2] ? match[2].toLowerCase() : ""
  return value * (units[unit] || 1)
}

const logger = {
  error: (message, meta) => winstonLogger.error(message, meta),
  warn: (message, meta) => winstonLogger.warn(message, meta),
  info: (message, meta) => winstonLogger.info(message, meta),
  debug: (message, meta) => winstonLogger.debug(message, meta),

  success: (message, meta) => {
    winstonLogger.info(`✓ ${message}`, meta)
  },

  syncStats: (synced, failed, total, duration) => {
    const message = `Sync completed: ${synced} synced, ${failed} failed out of ${total} records in ${duration}ms`
    if (failed > 0) {
      winstonLogger.warn(message)
    } else {
      winstonLogger.info(`✓ ${message}`)
    }
  },

  punchSync: (esslCode, employeeName, zohoId, punchTime, success, error = null) => {
    const status = success ? "✓ SUCCESS" : "✗ FAILED"
    const message = `${status} | eSSL: ${esslCode} | Name: ${employeeName} | Zoho: ${zohoId} | Time: ${punchTime}${error ? ` | Error: ${error}` : ""}`

    if (success) {
      winstonLogger.info(message)
    } else {
      winstonLogger.error(message)
    }
  },

  apiCall: (service, method, status) => {
    const message = `${service}.${method}() - ${status}`
    winstonLogger.debug(message)
  },

  withContext: (context) => {
    return {
      error: (message, meta) => winstonLogger.error(message, { ...meta, context }),
      warn: (message, meta) => winstonLogger.warn(message, { ...meta, context }),
      info: (message, meta) => winstonLogger.info(message, { ...meta, context }),
      debug: (message, meta) => winstonLogger.debug(message, { ...meta, context }),
    }
  },
}

module.exports = logger
