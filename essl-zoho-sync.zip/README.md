# eSSL to Zoho People Sync Service

Production-ready Node.js service that automatically syncs biometric attendance data from eSSL devices to Zoho People.

## Features

- **Automatic Sync**: Continuously polls eSSL devices and pushes attendance to Zoho People
- **Time-Based Intervals**: More frequent syncing after 10am for late arrivals and lunch punches
- **OAuth 2.0**: Secure authentication with Zoho People API
- **Adaptive Intervals**: Intelligent polling that adjusts based on time of day
- **Batch Processing**: Efficient handling of multiple punch records
- **Error Recovery**: Automatic retry with exponential backoff
- **Detailed Logging**: Separate punch logs with employee codes, names, and times
- **Health Monitoring**: Built-in health checks and status dashboard
- **Production Ready**: PM2 process management, logging, and monitoring

## Prerequisites

- Node.js 16+ 
- eSSL eBioServerNew running and accessible
- Zoho People account with API access
- Zoho OAuth credentials (Client ID & Secret)

## Quick Start

### 1. Installation

\`\`\`bash
npm install
\`\`\`

### 2. Configuration

\`\`\`bash
# Copy environment template
cp .env.example .env

# Edit .env with your credentials
nano .env
\`\`\`

**Important Configuration Notes:**

- **ESSL_LOCATION_CODE**: Leave empty if you have only one location (most common)
  \`\`\`env
  ESSL_LOCATION_CODE=
  \`\`\`
  See [LOCATION_SETUP.md](LOCATION_SETUP.md) for details.

### 3. Find Your Location Code (Optional)

\`\`\`bash
npm run list-locations
\`\`\`

This will show you all locations in your eSSL system. For single-location setups, you can skip this and leave `ESSL_LOCATION_CODE` empty.

### 4. Find Employee Codes and IDs

**Step 4a: Get eSSL Employee Codes**

\`\`\`bash
npm run fetch-essl-employees
\`\`\`

This will:
- Fetch all employees from eSSL
- Display employee codes and names
- Save to `essl-employees.json`
- Generate mapping template

**Step 4b: Get Zoho Employee IDs**

\`\`\`bash
npm run fetch-zoho-employees
\`\`\`

This will:
- Fetch all employees from Zoho People
- Display employee IDs and names
- Save to `zoho-employees.json`

### 5. Create Employee Mapping

Edit `src/config/employee-mapping.js` to map eSSL codes to Zoho IDs:

\`\`\`javascript
module.exports = {
  'E001': '1234567890',  // John Doe
  'E002': '1234567891',  // Jane Smith
  'E003': '1234567892',  // Bob Johnson
};
\`\`\`

See [EMPLOYEE_MAPPING_GUIDE.md](EMPLOYEE_MAPPING_GUIDE.md) for detailed instructions.

### 6. Zoho OAuth Setup

\`\`\`bash
npm run oauth-setup
\`\`\`

Follow the prompts to authorize the application with Zoho People.

### 7. Test Connections

\`\`\`bash
# Test eSSL connection
npm run test-essl

# Test Zoho connection
npm run test-zoho
\`\`\`

### 8. Watch Real-Time Punches (Optional)

\`\`\`bash
npm run watch-punches
\`\`\`

This monitors punches in real-time and shows which employees are mapped correctly.

### 9. Start Service

**Development:**
\`\`\`bash
npm run dev
\`\`\`

**Production (with PM2):**
\`\`\`bash
npm run pm2:start
\`\`\`

## Time-Based Sync Intervals

The system automatically adjusts sync frequency based on time of day:

| Time Period | Interval | Purpose |
|-------------|----------|---------|
| Before 8am | 5 minutes | Low activity period |
| 8am - 11am | **15 seconds** | Morning arrivals, late punches after 10am |
| 11am - 2pm | 30 seconds | Lunch time punches |
| 2pm - 6pm | **15 seconds** | Afternoon activity, early departures |
| After 6pm | 30 seconds | Evening activity |

**Key Benefits:**
- Late arrivals after 10am are synced within 15 seconds
- Lunch break punches are captured quickly
- System is efficient during low-activity periods
- No manual intervention needed

## Logging

### Punch Logs

All punch syncs are logged with detailed information:

\`\`\`bash
tail -f logs/punch.log
\`\`\`

**Log Format:**
\`\`\`
2025-01-15 09:30:15 | ✓ SUCCESS | eSSL: E001 | Name: John Doe | Zoho: 1234567890 | Time: 2025-01-15 09:30:00
2025-01-15 10:15:20 | ✓ SUCCESS | eSSL: E002 | Name: Jane Smith | Zoho: 1234567891 | Time: 2025-01-15 10:15:00
2025-01-15 10:20:30 | ✗ FAILED | eSSL: E999 | Name: Unknown | Zoho: NOT_MAPPED | Time: 2025-01-15 10:20:00
\`\`\`

### Application Logs

\`\`\`bash
tail -f logs/app.log
\`\`\`

### Error Logs

\`\`\`bash
tail -f logs/error.log
\`\`\`

## Employee Mapping

### Quick Commands

| Task | Command |
|------|---------|
| List locations | `npm run list-locations` |
| Fetch eSSL employees | `npm run fetch-essl-employees` |
| Fetch Zoho employees | `npm run fetch-zoho-employees` |
| Watch real-time punches | `npm run watch-punches` |
| View punch logs | `tail -f logs/punch.log` |

### How to Find Employee Codes

**eSSL Employee Code:**
1. Run `npm run fetch-essl-employees`
2. Check the output or `essl-employees.json`
3. Employee codes are shown in the first column

**Zoho Employee ID:**
1. Run `npm run fetch-zoho-employees`
2. Check the output or `zoho-employees.json`
3. Employee IDs are shown in the first column

**Match and Map:**
1. Compare employee names from both systems
2. Add mappings to `src/config/employee-mapping.js`
3. Test with `npm run watch-punches`

See [EMPLOYEE_MAPPING_GUIDE.md](EMPLOYEE_MAPPING_GUIDE.md) for complete instructions.

## Configuration

### eSSL Settings

- `ESSL_WEBSERVICE_URL`: URL of your eBioServerNew SOAP API
- `ESSL_USERNAME`: eBioServerNew admin username
- `ESSL_PASSWORD`: eBioServerNew admin password
- `ESSL_LOCATION_CODE`: Location code (**leave empty for single location**)

### Sync Intervals

- `ESSL_BASE_INTERVAL`: Normal polling interval (30000ms = 30 seconds)
- `ESSL_MIN_INTERVAL`: Minimum interval during peak hours (15000ms = 15 seconds)
- `ESSL_MAX_INTERVAL`: Maximum interval during low activity (300000ms = 5 minutes)

### Zoho OAuth

Get your OAuth credentials from [Zoho API Console](https://api-console.zoho.in/):

1. Create a new "Server-based Application"
2. Set redirect URI to `http://localhost:3000/oauth/callback`
3. Add required scopes: `ZohoPeople.attendance.CREATE`, `ZohoPeople.forms.READ`
4. Copy Client ID and Client Secret to `.env`

## Monitoring

### Health Check Dashboard

Access the health dashboard at: `http://localhost:3000/health`

### PM2 Monitoring

\`\`\`bash
# View logs
npm run pm2:logs

# Monitor resources
npm run pm2:monit

# Restart service
npm run pm2:restart
\`\`\`

### Real-Time Punch Monitoring

\`\`\`bash
npm run watch-punches
\`\`\`

This shows:
- Real-time punch events as they happen
- Employee codes and names
- Mapping status (✓ mapped, ✗ not mapped)
- Saves to `logs/punch-monitor.log`

## API Endpoints

- `GET /health` - Health check and service status
- `GET /stats` - Sync statistics
- `GET /oauth/authorize` - Start OAuth flow
- `GET /oauth/callback` - OAuth callback handler

## Troubleshooting

### Location Code Questions

See [LOCATION_SETUP.md](LOCATION_SETUP.md) for complete guide.

**Quick answer:** If you have only one office, leave `ESSL_LOCATION_CODE` empty in your `.env` file.

### No Data Syncing

**Check employee mapping:**
\`\`\`bash
npm run watch-punches
\`\`\`

Look for ✗ symbols indicating unmapped employees.

**Check logs:**
\`\`\`bash
tail -f logs/punch.log
\`\`\`

### Late Arrivals Not Syncing Fast Enough

The system automatically uses 15-second intervals between 8am-11am. If you need faster:

1. Edit `.env`:
\`\`\`
ESSL_MIN_INTERVAL=10000  # 10 seconds
\`\`\`

2. Restart service:
\`\`\`bash
npm run pm2:restart
\`\`\`

### Employee Not Found

**eSSL side:**
\`\`\`bash
npm run fetch-essl-employees
\`\`\`

Check if employee exists in the list.

**Zoho side:**
\`\`\`bash
npm run fetch-zoho-employees
\`\`\`

Check if employee exists in Zoho People.

### Token Expired

\`\`\`bash
npm run oauth-setup
\`\`\`

## Production Deployment

### Using PM2

\`\`\`bash
# Start with PM2
npm run pm2:start

# Enable startup on boot
pm2 startup
pm2 save
\`\`\`

### Using Docker

\`\`\`bash
docker-compose up -d
\`\`\`

## Architecture

\`\`\`
src/
├── config/          # Configuration files
│   ├── config.js
│   └── employee-mapping.js
├── services/        # Core services
│   ├── ESSLService.js
│   ├── ZohoService.js
│   ├── ZohoOAuthService.js
│   └── OptimizedSyncService.js
├── utils/           # Utilities
│   ├── logger.js
│   └── HealthMonitor.js
├── routes/          # Express routes
└── index.js         # Application entry point

scripts/
├── list-locations.js          # Find your location code
├── fetch-essl-employees.js    # Fetch eSSL employee codes
├── fetch-zoho-employees.js    # Fetch Zoho employee IDs
├── watch-punches.js           # Real-time punch monitor
├── test-essl.js               # Test eSSL connection
├── test-zoho.js               # Test Zoho connection
└── oauth-setup.js             # OAuth setup wizard

logs/
├── app.log           # Application logs
├── error.log         # Error logs only
├── punch.log         # Detailed punch sync logs
└── punch-monitor.log # Real-time punch monitoring
\`\`\`

## What I Understand - System Workflow

### 1. Location Code (ESSL_LOCATION_CODE)

**What it is:**
- An organizational identifier in eSSL system
- Used to group devices and employees by branch/office

**Do you need it?**
- **Single location:** NO - leave it empty
- **Multiple locations:** Optional - leave empty to sync all, or specify one location

**How to find it:**
\`\`\`bash
npm run list-locations
\`\`\`

### 2. Finding Employee Codes

**eSSL Employee Codes:**
- Run `npm run fetch-essl-employees`
- System connects to eSSL SOAP API
- Fetches all employee codes and names
- Saves to `essl-employees.json`
- Generates mapping template

**Zoho Employee IDs:**
- Run `npm run fetch-zoho-employees`
- System connects to Zoho People API
- Fetches all employee IDs and names
- Saves to `zoho-employees.json`

### 3. Time-Based Syncing

**Before 10am:**
- System polls every 5 minutes (low activity)

**After 10am (8am-11am):**
- System polls every **15 seconds**
- Catches late arrivals quickly
- Syncs within 15 seconds of punch

**Lunch Time (11am-2pm):**
- System polls every 30 seconds
- Captures lunch break punches

**Afternoon (2pm-6pm):**
- System polls every **15 seconds**
- Catches early departures

### 4. Punch Logging

**When user punches:**
1. eSSL device records punch
2. Sync service fetches punch data (every 15-30 seconds based on time)
3. Looks up employee mapping
4. Sends to Zoho People API
5. Logs detailed information:
   - ✓ SUCCESS or ✗ FAILED
   - eSSL employee code
   - Employee name
   - Zoho employee ID
   - Punch time
   - Any errors

**Log file location:** `logs/punch.log`

**Example log entry:**
\`\`\`
2025-01-15 10:25:30 | ✓ SUCCESS | eSSL: E001 | Name: John Doe | Zoho: 1234567890 | Time: 2025-01-15 10:25:00
\`\`\`

### 5. Testing Made Easy

**Real-time monitoring:**
\`\`\`bash
npm run watch-punches
\`\`\`

Shows live punch events with:
- Employee code
- Employee name
- Punch time
- Device name
- Mapping status (✓ or ✗)

**Check logs:**
\`\`\`bash
tail -f logs/punch.log
\`\`\`

See all synced punches with full details.

## Support

For issues or questions:
1. Check location setup: [LOCATION_SETUP.md](LOCATION_SETUP.md)
2. Check logs: `tail -f logs/punch.log`
3. Watch real-time: `npm run watch-punches`
4. Review health status: `http://localhost:3000/health`
5. Test connections: `npm run test-essl` and `npm run test-zoho`
6. Read [EMPLOYEE_MAPPING_GUIDE.md](EMPLOYEE_MAPPING_GUIDE.md)

## License

MIT
