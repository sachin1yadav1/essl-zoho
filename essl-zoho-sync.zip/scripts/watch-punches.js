#!/usr/bin/env node

require("dotenv").config()
const ESSLService = require("../src/services/ESSLService")
const employeeMapping = require("../src/config/employee-mapping")
const moment = require("moment")
const fs = require("fs")
const path = require("path")

async function watchPunches() {
  console.log("=".repeat(70))
  console.log("Real-Time Punch Monitor")
  console.log("=".repeat(70))
  console.log()
  console.log("Watching for new punches... (Press Ctrl+C to stop)")
  console.log()

  const esslService = new ESSLService()
  await esslService.initialize()

  let lastSyncTime = moment().subtract(5, "minutes").format("YYYY-MM-DD HH:mm:ss")
  const logFile = path.join(__dirname, "..", "logs", "punch-monitor.log")

  // Ensure logs directory exists
  const logsDir = path.dirname(logFile)
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true })
  }

  const logToFile = (message) => {
    const timestamp = moment().format("YYYY-MM-DD HH:mm:ss")
    fs.appendFileSync(logFile, `${timestamp} | ${message}\n`)
  }

  console.log(`Log file: ${logFile}`)
  console.log()

  setInterval(async () => {
    try {
      const currentTime = moment().format("YYYY-MM-DD HH:mm:ss")
      const transactions = await esslService.getTransactions(lastSyncTime, currentTime)

      if (transactions.length > 0) {
        console.log(`\n[${moment().format("HH:mm:ss")}] Found ${transactions.length} new punch(es)`)
        console.log("-".repeat(70))

        transactions.forEach((t) => {
          const zohoId = employeeMapping[t.EmployeeCode] || "NOT_MAPPED"
          const status = zohoId !== "NOT_MAPPED" ? "✓" : "✗"

          const message = `${status} eSSL: ${t.EmployeeCode} | Name: ${t.EmployeeName || "Unknown"} | Time: ${t.PunchDate} ${t.PunchTime} | Device: ${t.DeviceName} | Zoho: ${zohoId}`

          console.log(message)
          logToFile(message)
        })

        console.log("-".repeat(70))
      }

      lastSyncTime = currentTime
    } catch (error) {
      console.error(`Error: ${error.message}`)
      logToFile(`ERROR: ${error.message}`)
    }
  }, 10000) // Check every 10 seconds
}

watchPunches()
