#!/usr/bin/env node

const fs = require("fs").promises
const path = require("path")
const readline = require("readline")

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})

const question = (query) => new Promise((resolve) => rl.question(query, resolve))

async function setup() {
  console.log("=".repeat(60))
  console.log("eSSL to Zoho People Sync - Setup Wizard")
  console.log("=".repeat(60))
  console.log()

  try {
    // Check if .env exists
    const envPath = path.join(process.cwd(), ".env")
    let envExists = false

    try {
      await fs.access(envPath)
      envExists = true
    } catch (error) {
      // File doesn't exist
    }

    if (envExists) {
      const overwrite = await question(".env file already exists. Overwrite? (y/N): ")
      if (overwrite.toLowerCase() !== "y") {
        console.log("Setup cancelled.")
        rl.close()
        return
      }
    }

    console.log("\n--- eSSL Configuration ---\n")

    const esslUrl = await question("eSSL Webservice URL (e.g., http://192.168.1.100/webservice.asmx): ")
    const esslUsername = await question("eSSL Username: ")
    const esslPassword = await question("eSSL Password: ")
    const esslLocation = await question("eSSL Location Code (leave empty for all locations): ")

    console.log("\n--- Zoho OAuth Configuration ---\n")
    console.log("Get your OAuth credentials from: https://api-console.zoho.in/\n")

    const zohoClientId = await question("Zoho Client ID: ")
    const zohoClientSecret = await question("Zoho Client Secret: ")
    const zohoRedirectUri =
      (await question("Zoho Redirect URI (default: http://localhost:3000/oauth/callback): ")) ||
      "http://localhost:3000/oauth/callback"

    console.log("\n--- Sync Configuration ---\n")

    const syncInterval = (await question("Base sync interval in seconds (default: 30): ")) || "30"
    const batchSize = (await question("Batch size for processing (default: 10): ")) || "10"

    // Create .env content
    const envContent = `# eSSL eBioServerNew Configuration
ESSL_WEBSERVICE_URL=${esslUrl}
ESSL_USERNAME=${esslUsername}
ESSL_PASSWORD=${esslPassword}
ESSL_LOCATION_CODE=${esslLocation}

# Sync Configuration
ESSL_BASE_INTERVAL=${Number.parseInt(syncInterval) * 1000}
ESSL_MIN_INTERVAL=15000
ESSL_MAX_INTERVAL=300000
ESSL_DATE_FORMAT=YYYY-MM-DD HH:mm:ss
ESSL_INITIAL_SYNC_WINDOW_MINUTES=120
LAST_SYNC_TIME=

# Zoho People OAuth Configuration (India DC)
ZOHO_CLIENT_ID=${zohoClientId}
ZOHO_CLIENT_SECRET=${zohoClientSecret}
ZOHO_REDIRECT_URI=${zohoRedirectUri}
ZOHO_SCOPE=ZohoPeople.attendance.CREATE,ZohoPeople.forms.READ

# Zoho API URLs (India DC)
ZOHO_ACCOUNTS_URL=https://accounts.zoho.in
ZOHO_API_URL=https://people.zoho.in/people/api
ZOHO_ATTENDANCE_API_URL=https://people.zoho.in/people/api/attendance
ZOHO_EMPLOYEE_API_URL=https://people.zoho.in/api/forms/P_EmployeeView/records

# Zoho OAuth Tokens (Auto-populated after OAuth setup)
ZOHO_ACCESS_TOKEN=
ZOHO_REFRESH_TOKEN=
ZOHO_TOKEN_EXPIRES_AT=

# Zoho API Configuration
ZOHO_TIMEOUT=15000
ZOHO_MAX_RETRIES=3
ZOHO_RATE_LIMIT_DELAY=1000

# Sync Settings
SYNC_BATCH_SIZE=${batchSize}
SYNC_EMPTY_POLLS_TO_BACKOFF=5
SYNC_BACKOFF_FACTOR=1.5

# Health Monitor
HEALTH_CHECK_PORT=3000
HEALTH_CHECK_ENABLED=true

# Logging
LOG_LEVEL=info
LOG_FILE=logs/app.log
LOG_MAX_SIZE=10m
LOG_MAX_FILES=7

# Environment
NODE_ENV=production
`

    // Write .env file
    await fs.writeFile(envPath, envContent, "utf8")
    console.log("\n✓ .env file created successfully")

    // Create logs directory
    const logsDir = path.join(process.cwd(), "logs")
    try {
      await fs.mkdir(logsDir, { recursive: true })
      console.log("✓ Logs directory created")
    } catch (error) {
      // Directory might already exist
    }

    console.log("\n--- Next Steps ---\n")
    console.log("1. Edit src/config/employee-mapping.js to map eSSL codes to Zoho IDs")
    console.log("2. Run: npm run oauth-setup (to authorize with Zoho)")
    console.log("3. Run: npm run test-essl (to test eSSL connection)")
    console.log("4. Run: npm run test-zoho (to test Zoho connection)")
    console.log("5. Run: npm start (to start the sync service)")
    console.log("\nFor production deployment with PM2:")
    console.log("  npm run pm2:start")
    console.log()
  } catch (error) {
    console.error("Setup failed:", error.message)
  } finally {
    rl.close()
  }
}

setup()
