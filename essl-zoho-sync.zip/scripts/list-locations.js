#!/usr/bin/env node

/**
 * List all locations from eSSL system
 * This helps you find your ESSL_LOCATION_CODE
 */

require("dotenv").config()
const soap = require("soap")
const config = require("../src/config/config")

async function listLocations() {
  console.log("\n=== eSSL Location Finder ===\n")

  try {
    console.log("Connecting to eSSL service...")
    const client = await soap.createClientAsync(config.essl.webserviceUrl)

    // Get all devices to extract unique locations
    const args = {
      UserName: config.essl.username,
      Password: config.essl.password,
      Location: "", // Empty to get all locations
    }

    console.log("Fetching device list...\n")
    const [result] = await client.GetDeviceListAsync(args)

    if (!result || !result.GetDeviceListResult) {
      console.log("✓ No locations found or you have a single default location")
      console.log("\n📝 RECOMMENDATION:")
      console.log("   Leave ESSL_LOCATION_CODE empty in your .env file")
      console.log("   ESSL_LOCATION_CODE=")
      return
    }

    // Parse device result to extract locations
    const resultString = result.GetDeviceListResult
    const records = resultString.split(";").filter((r) => r.trim())
    const locations = new Set()

    for (const record of records) {
      const fields = record.split(",").map((f) => f.trim())
      if (fields.length >= 3) {
        locations.add(fields[2]) // Location is 3rd field
      }
    }

    if (locations.size === 0) {
      console.log("✓ No specific locations configured")
      console.log("\n📝 RECOMMENDATION:")
      console.log("   Leave ESSL_LOCATION_CODE empty in your .env file")
      console.log("   ESSL_LOCATION_CODE=")
    } else if (locations.size === 1) {
      const locationCode = Array.from(locations)[0]
      console.log(`✓ Found 1 location: "${locationCode}"`)
      console.log("\n📝 RECOMMENDATION:")
      console.log("   You can either:")
      console.log(`   1. Use specific location: ESSL_LOCATION_CODE=${locationCode}`)
      console.log("   2. Leave empty for all:   ESSL_LOCATION_CODE=")
      console.log("\n   Both will work the same for single location setup")
    } else {
      console.log(`✓ Found ${locations.size} locations:\n`)
      Array.from(locations).forEach((loc, index) => {
        console.log(`   ${index + 1}. ${loc}`)
      })
      console.log("\n📝 RECOMMENDATION:")
      console.log("   Choose one of the above location codes:")
      console.log(`   ESSL_LOCATION_CODE=<location_code>`)
      console.log("\n   Or leave empty to sync from ALL locations:")
      console.log("   ESSL_LOCATION_CODE=")
    }

    console.log("\n" + "=".repeat(50))
  } catch (error) {
    console.error("\n❌ Error:", error.message)
    console.log("\n💡 TROUBLESHOOTING:")
    console.log("   1. Check ESSL_WEBSERVICE_URL is correct")
    console.log("   2. Verify ESSL_USERNAME and ESSL_PASSWORD")
    console.log("   3. Ensure eSSL service is running and accessible")
  }
}

listLocations()
