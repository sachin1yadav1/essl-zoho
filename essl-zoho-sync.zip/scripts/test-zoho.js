#!/usr/bin/env node

require("dotenv").config()
const ZohoService = require("../src/services/ZohoService")
const logger = require("../src/utils/logger")

async function testZoho() {
  console.log("=".repeat(60))
  console.log("Testing Zoho People Connection")
  console.log("=".repeat(60))
  console.log()

  const zohoService = new ZohoService()

  try {
    const result = await zohoService.testConnection()

    if (result.success) {
      console.log("✓ Connection successful!")
      console.log()
      console.log("API Endpoint:", result.apiEndpoint)
      console.log("Employees found:", result.employeeCount)
      console.log()
      console.log("Token Info:")
      console.log("  Has Access Token:", result.tokenInfo.hasAccessToken)
      console.log("  Has Refresh Token:", result.tokenInfo.hasRefreshToken)
      console.log("  Is Valid:", result.tokenInfo.isValid)
      console.log("  Expires At:", result.tokenInfo.expiresAt)
      console.log()

      // Try to get employees
      if (result.employeeCount > 0) {
        console.log("Fetching employee details...")
        const employeesResult = await zohoService.getAllEmployees()

        if (employeesResult.success) {
          const employees = employeesResult.data
          console.log(`✓ Retrieved ${employees.length} employees`)
          console.log()
          console.log("Sample employees:")
          employees.slice(0, 3).forEach((emp) => {
            console.log(`  - ${emp.EmployeeID || emp.Employee_ID}: ${emp.EmployeeName || emp.Employee_Name}`)
          })
          if (employees.length > 3) {
            console.log(`  ... and ${employees.length - 3} more`)
          }
        }
      }
    } else {
      console.log("✗ Connection failed!")
      console.log()
      console.log("Error:", result.error)
      console.log()

      if (!result.tokenInfo?.hasAccessToken) {
        console.log("No access token found. Please run: npm run oauth-setup")
      } else if (!result.tokenInfo?.isValid) {
        console.log("Access token expired. Please run: npm run oauth-setup")
      } else {
        console.log("Please check:")
        console.log("  - OAuth credentials are correct")
        console.log("  - API permissions are granted")
        console.log("  - Zoho People account is active")
      }
    }
  } catch (error) {
    console.log("✗ Test failed!")
    console.log()
    console.log("Error:", error.message)
  }

  console.log()
}

testZoho()
