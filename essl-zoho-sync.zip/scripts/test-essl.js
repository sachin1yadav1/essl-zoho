#!/usr/bin/env node

require("dotenv").config()
const ESSLService = require("../src/services/ESSLService")
const logger = require("../src/utils/logger")

async function testESSL() {
  console.log("=".repeat(60))
  console.log("Testing eSSL Connection")
  console.log("=".repeat(60))
  console.log()

  const esslService = new ESSLService()

  try {
    const result = await esslService.testConnection()

    if (result.success) {
      console.log("✓ Connection successful!")
      console.log()
      console.log("Devices found:", result.deviceCount)
      console.log()

      if (result.devices && result.devices.length > 0) {
        console.log("Device List:")
        result.devices.forEach((device, index) => {
          console.log(`  ${index + 1}. ${device.DeviceName} (${device.SerialNumber})`)
          console.log(`     Location: ${device.Location}`)
          console.log(`     Status: ${device.Status}`)
          console.log()
        })
      }

      // Try to get employee codes
      console.log("Fetching employee codes...")
      const codes = await esslService.getEmployeeCodes()
      console.log(`✓ Found ${codes.length} employees`)

      if (codes.length > 0) {
        console.log()
        console.log("Sample employee codes:")
        codes.slice(0, 5).forEach((code) => {
          console.log(`  - ${code}`)
        })
        if (codes.length > 5) {
          console.log(`  ... and ${codes.length - 5} more`)
        }
      }
    } else {
      console.log("✗ Connection failed!")
      console.log()
      console.log("Error:", result.error)
      console.log()
      console.log("Please check:")
      console.log("  - ESSL_WEBSERVICE_URL is correct")
      console.log("  - ESSL_USERNAME and ESSL_PASSWORD are correct")
      console.log("  - eBioServerNew is running and accessible")
    }
  } catch (error) {
    console.log("✗ Test failed!")
    console.log()
    console.log("Error:", error.message)
  }

  console.log()
}

testESSL()
