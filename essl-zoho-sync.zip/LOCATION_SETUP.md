# eSSL Location Code Setup Guide

## What is ESSL_LOCATION_CODE?

The `ESSL_LOCATION_CODE` is an organizational identifier used by eSSL eBioServerNew to group devices and employees. Think of it like a branch or office code.

## Do I Need It?

**If you have only ONE location:** ✅ **NO, leave it empty**

**If you have MULTIPLE locations:** You can either:
- Leave it empty to sync from ALL locations
- Specify one location code to sync only that location

## How to Find Your Location Code

### Method 1: Use the Location Finder Script

\`\`\`bash
npm run list-locations
\`\`\`

This will:
- Connect to your eSSL system
- List all configured locations
- Show recommendations based on your setup

**Example Output:**

\`\`\`
=== eSSL Location Finder ===

Connecting to eSSL service...
Fetching device list...

✓ Found 1 location: "MAIN_OFFICE"

📝 RECOMMENDATION:
   You can either:
   1. Use specific location: ESSL_LOCATION_CODE=MAIN_OFFICE
   2. Leave empty for all:   ESSL_LOCATION_CODE=

   Both will work the same for single location setup
\`\`\`

### Method 2: Check eSSL eBioServerNew Application

1. Open eSSL eBioServerNew application
2. Go to **Settings** → **Locations**
3. You'll see a list of location codes
4. Copy the code you want to use

### Method 3: Leave It Empty (Recommended for Single Location)

If you only have one office/location, just leave it empty:

\`\`\`env
ESSL_LOCATION_CODE=
\`\`\`

The system will automatically fetch data from all locations, which works perfectly for single-location setups.

## Configuration Examples

### Single Location Setup (Most Common)

\`\`\`env
# .env file
ESSL_WEBSERVICE_URL=http://192.168.1.100/webservice.asmx
ESSL_USERNAME=admin
ESSL_PASSWORD=admin123
ESSL_LOCATION_CODE=
\`\`\`

**Result:** System syncs all employees and devices from your single location.

### Multiple Locations - Sync All

\`\`\`env
ESSL_LOCATION_CODE=
\`\`\`

**Result:** System syncs employees and devices from ALL locations.

### Multiple Locations - Sync Specific Location

\`\`\`env
ESSL_LOCATION_CODE=BRANCH_A
\`\`\`

**Result:** System syncs only employees and devices from "BRANCH_A".

## How Location Code is Used

The location code is passed to eSSL API calls:

1. **GetDeviceLogs** - Fetches punch records from specified location(s)
2. **GetDeviceList** - Lists devices in specified location(s)
3. **GetEmployeeCodes** - Gets employees from specified location(s)

When empty, the API returns data from ALL locations.

## Troubleshooting

### "I don't know my location code"

Run the location finder:
\`\`\`bash
npm run list-locations
\`\`\`

### "Script says no locations found"

This means you have a default single-location setup. Leave `ESSL_LOCATION_CODE` empty:
\`\`\`env
ESSL_LOCATION_CODE=
\`\`\`

### "I have multiple locations but want to sync all"

Leave it empty:
\`\`\`env
ESSL_LOCATION_CODE=
\`\`\`

### "I want to sync only one specific location"

1. Run `npm run list-locations` to see all locations
2. Copy the location code you want
3. Set it in `.env`:
\`\`\`env
ESSL_LOCATION_CODE=YOUR_LOCATION_CODE
\`\`\`

## Quick Decision Guide

\`\`\`
Do you have multiple physical offices/branches?
│
├─ NO → Leave ESSL_LOCATION_CODE empty
│       ESSL_LOCATION_CODE=
│
└─ YES → Do you want to sync all locations?
         │
         ├─ YES → Leave ESSL_LOCATION_CODE empty
         │        ESSL_LOCATION_CODE=
         │
         └─ NO → Run: npm run list-locations
                 Copy the location code
                 ESSL_LOCATION_CODE=YOUR_CODE
\`\`\`

## Summary

For most users with a single office:
\`\`\`env
ESSL_LOCATION_CODE=
\`\`\`

This is the simplest and recommended configuration.
